//
//  SatinStitch.swift
//  BianCore
//
//  Created by T Krobot on 21/9/23.
//

import Foundation

// SatinStitch is just a ZigZagStitch in disguise lol
public struct SatinStitch: StitchType {
    public var name: String = "Satin Stitch"
    
    public var width: EmbroideryDistance
    
    private var zigZagStitch: ZigZagStitch
    
    public init(width: EmbroideryDistance) {
        self.width = width
        self.zigZagStitch = ZigZagStitch(density: .mm(0.5), width: width)
    }
    public init(width: Double) {
        self.init(width: .mm(width))
    }
    public init(width: Int) {
        self.init(width: .mm(width))
    }
    
    
    public func calcOps(withLength length: EmbroideryDistance, from position: EmbroideryPoint, facing angle: EmbroideryAngle, color: EmbroideryColor) -> BothOpTypes {
        return self.zigZagStitch.calcOps(withLength: length, from: position, facing: angle, color: color)
    }
    
    
}
