//
//  Operation.swift
//  BERNINA
//
//  Created by Jia Chen Yee on 7/10/22.
//

import Foundation

public struct Operation: Codable {
    
    var type: OperationType
    /// An array with two items representing the coord in millimeters
    var cord: [Double]
    
    var cgPoint: CGPoint {
        CGPoint(x: cord[0], y: cord[1])
    }
    var embroideryPoint: EmbroideryPoint {
        EmbroideryPoint(x: cord[0], y: cord[1])
    }
    
    var color: EmbroideryColor?
    
    init(type: OperationType, at cord: [Double]) {
        self.type = type
        self.cord = cord
    }
    
    init(type: OperationType, at cord: EmbroideryPoint) {
        self.type = type
        self.cord = [cord.x.mm, cord.y.mm]
    }
    
    init(type: OperationType, at cord: EmbroideryPoint, color: EmbroideryColor? = nil) {
        self.type = type
        self.cord = [cord.x.mm, cord.y.mm]
        self.color = color
    }
    
    init?(dict: [String: Any]) {
        guard let type = dict["type"] as? OperationType,
              let cord = dict["cord"] as? [Double] else { return nil }
        
        self.type = type
        self.cord = cord
    }
}
