//
//  EmbroideryPoint.swift
//  BianCore
//
//  Created by Jia Chen Yee on 19/2/23.
//

import Foundation
import UIKit

/// Everything on the Project side of things should use EmbroideryPoint, everything on the drawing-to-the-screen side of things should use CGPoint
public struct EmbroideryPoint: Codable {
    public var x: EmbroideryDistance
    public var y: EmbroideryDistance
    
//    var cgPoint: CGPoint {
//        CGPoint(x: x.millimeters, y: y.millimeters)
//    }
    
    public init(x: Int, y: Int) {
        self.x = .millimeters(Double(x))
        self.y = .millimeters(Double(y))
    }
    
    public init(x: Double, y: Double) {
        self.x = .millimeters(x)
        self.y = .millimeters(y)
    }
    
    public init(x: EmbroideryDistance, y: EmbroideryDistance) {
        self.x = x
        self.y = y
    }
}
