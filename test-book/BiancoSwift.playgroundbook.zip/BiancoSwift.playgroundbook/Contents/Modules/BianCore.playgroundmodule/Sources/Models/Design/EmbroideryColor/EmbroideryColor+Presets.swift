//
//  EmbroideryColor+Presets.swift
//  BianCore
//
//  Created by Jia Chen Yee on 19/2/23.
//

import Foundation

extension EmbroideryColor {
    public static let blue = EmbroideryColor(name: "Blue", red: 40, green: 22, blue: 111)
    public static let cyan = EmbroideryColor(name: "Cyan", red: 0, green: 147, blue: 221)
    public static let green = EmbroideryColor(name: "Green", red: 0, green: 146, blue: 63)
    public static let yellow = EmbroideryColor(name: "Yellow", red: 255, green: 245, blue: 0)
    public static let red = EmbroideryColor(name: "Red", red: 218, green: 27, blue: 29)
    public static let brickRed = EmbroideryColor(name: "Brick Red", red: 183, green: 103, blue: 60)
    public static let magenta = EmbroideryColor(name: "Magenta", red: 221, green: 19, blue: 123)
    public static let purple = EmbroideryColor(name: "Purple", red: 151, green: 69, blue: 120)
    public static let orange = EmbroideryColor(name: "Orange", red: 231, green: 120, blue: 23)
    public static let pink = EmbroideryColor(name: "Pink", red: 239, green: 155, blue: 160)
    public static let darkBrown = EmbroideryColor(name: "Dark Brown", red: 113, green: 98, blue: 91)
    public static let powderBlue = EmbroideryColor(name: "Powder Blue", red: 186, green: 179, blue: 214)
    public static let black = EmbroideryColor(name: "Black", red: 31, green: 26, blue: 23)
    public static let grey = EmbroideryColor(name: "Grey", red: 131, green: 130, blue: 129)
    public static let white = EmbroideryColor(name: "White", red: 255, green: 255, blue: 255)
    public static let pastelBlue = EmbroideryColor(name: "Pastel Blue", red: 142, green: 132, blue: 183)
    public static let babyBlue = EmbroideryColor(name: "Baby Blue", red: 102, green: 122, blue: 179)
    public static let navyBlue = EmbroideryColor(name: "Navy Blue", red: 73, green: 86, blue: 116)
    public static let deepNavyBlue = EmbroideryColor(name: "Deep Navy Blue", red: 77, green: 72, blue: 91)
    public static let desertBlue = EmbroideryColor(name: "Desert Blue", red: 97, green: 111, blue: 133)
    public static let skyBlue = EmbroideryColor(name: "Sky Blue", red: 0, green: 124, blue: 195)
    public static let iceBlue = EmbroideryColor(name: "Ice Blue", red: 117, green: 197, blue: 240)
    public static let lightBlueGreen = EmbroideryColor(name: "Light BlueGreen", red: 150, green: 174, blue: 190)
    public static let oceanGreen = EmbroideryColor(name: "Ocean Green", red: 121, green: 137, blue: 146)
    public static let mossGreen = EmbroideryColor(name: "Moss Green", red: 94, green: 104, blue: 110)
    public static let lightGreen = EmbroideryColor(name: "Light Green", red: 68, green: 146, blue: 132)
    public static let turquoise = EmbroideryColor(name: "Turquoise", red: 59, green: 179, blue: 194)
    public static let seaGreen = EmbroideryColor(name: "Sea Green", red: 66, green: 146, blue: 157)
    public static let fadedGreen = EmbroideryColor(name: "Faded Green", red: 151, green: 175, blue: 160)
    public static let ghostGreen = EmbroideryColor(name: "Ghost Green", red: 182, green: 221, blue: 199)
    public static let mintGreen = EmbroideryColor(name: "Mint Green", red: 123, green: 196, blue: 160)
    public static let martianGreen = EmbroideryColor(name: "Martian Green", red: 153, green: 174, blue: 106)
    public static let chartreuse = EmbroideryColor(name: "Chartreuse", red: 132, green: 194, blue: 37)
    public static let moonGreen = EmbroideryColor(name: "Moon Green", red: 184, green: 219, blue: 124)
    public static let murkyGreen = EmbroideryColor(name: "Murky Green", red: 76, green: 72, blue: 64)
    public static let oliveDrab = EmbroideryColor(name: "Olive Drab", red: 113, green: 111, blue: 97)
    public static let khaki = EmbroideryColor(name: "Khaki", red: 151, green: 148, blue: 127)
    public static let olive = EmbroideryColor(name: "Olive", red: 151, green: 148, blue: 107)
    public static let bananaYellow = EmbroideryColor(name: "Banana Yellow", red: 196, green: 191, blue: 102)
    public static let lightYellow = EmbroideryColor(name: "Light Yellow", red: 255, green: 249, blue: 116)
    public static let chalk = EmbroideryColor(name: "Chalk", red: 255, green: 251, blue: 156)
    public static let paleYellow = EmbroideryColor(name: "Pale Yellow", red: 255, green: 252, blue: 200)
    public static let brown = EmbroideryColor(name: "Brown", red: 149, green: 127, blue: 102)
    public static let redBrown = EmbroideryColor(name: "Red Brown", red: 187, green: 130, blue: 91)
    public static let gold = EmbroideryColor(name: "Gold", red: 192, green: 160, blue: 98)
    public static let autumnOrange = EmbroideryColor(name: "Autumn Orange", red: 231, green: 120, blue: 68)
    public static let lightOrange = EmbroideryColor(name: "Light Orange", red: 239, green: 154, blue: 72)
    public static let peach = EmbroideryColor(name: "Peach", red: 238, green: 154, blue: 105)
    public static let deepYellow = EmbroideryColor(name: "Deep Yellow", red: 248, green: 165, blue: 0)
    public static let sand = EmbroideryColor(name: "Sand", red: 245, green: 196, blue: 145)
    public static let tropicalPink = EmbroideryColor(name: "Tropical Pink", red: 231, green: 120, blue: 95)
    public static let softPink = EmbroideryColor(name: "Soft Pink", red: 238, green: 154, blue: 133)
    public static let fadedPink = EmbroideryColor(name: "Faded Pink", red: 247, green: 197, blue: 180)
    public static let neonRed = EmbroideryColor(name: "Neon Red", red: 219, green: 33, blue: 76)
    public static let deepPink = EmbroideryColor(name: "Deep Pink", red: 232, green: 120, blue: 119)
    public static let hotPink = EmbroideryColor(name: "Hot Pink", red: 227, green: 85, blue: 106)
    
    static let allColors = [blue, cyan, green, yellow, red, brickRed, magenta, purple, orange, pink, darkBrown, powderBlue, black, grey, white, pastelBlue, babyBlue, navyBlue, deepNavyBlue, desertBlue, skyBlue, iceBlue, lightBlueGreen, oceanGreen, mossGreen, lightGreen, turquoise, seaGreen, fadedGreen, ghostGreen, mintGreen, martianGreen, chartreuse, moonGreen, murkyGreen, oliveDrab, khaki, olive, bananaYellow, lightYellow, chalk, paleYellow, brown, redBrown, gold, autumnOrange, lightOrange, peach, deepYellow, sand, tropicalPink, softPink, fadedPink, neonRed, deepPink, hotPink]
    
    public static func random() -> EmbroideryColor {
        allColors.randomElement()!
    }
}
