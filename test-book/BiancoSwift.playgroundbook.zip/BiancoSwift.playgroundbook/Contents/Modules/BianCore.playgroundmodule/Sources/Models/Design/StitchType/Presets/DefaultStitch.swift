//
//  DefaultStitch.swift
//  BianCore
//
//  Created by Sean Wong on 30/5/23.
//

import Foundation

public struct DefaultStitch: StitchType {
    
    // default run has no density
    public var density: EmbroideryDistance = .mm(0)
    
    public var name: String = "Default Stitch"
    
    public func calcOps(withLength length: EmbroideryDistance, from position: EmbroideryPoint, facing angle: EmbroideryAngle, color: EmbroideryColor) ->  BothOpTypes {
        
        let targetX = position.x.mm + length.mm * cos(angle.radians)
        let targetY = position.y.mm + length.mm * sin(angle.radians)
        
        let target = EmbroideryPoint(x: targetX, y: targetY)
        
        return StitchHelpers.moveOps(from: position, to: target, color: color)
    }
    
}
