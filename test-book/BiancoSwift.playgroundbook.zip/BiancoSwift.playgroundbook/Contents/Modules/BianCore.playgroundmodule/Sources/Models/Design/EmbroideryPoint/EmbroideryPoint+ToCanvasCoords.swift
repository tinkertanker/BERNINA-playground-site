//
//  Operation+ToStitchLines.swift
//  BianCore
//
//  Created by T Krobot on 14/9/23.
//

import Foundation
import SwiftUI

extension EmbroideryPoint {
    func toCanvasCoords() -> CGPoint {
        return CGPoint(x: self.x.mm, y: self.y.mm) * 10
    }
}
