//
//  StraightStitch.swift
//  BianCore
//
//  Created by Sean Wong on 24/5/23.
//

import Foundation

public struct RunningStitch: StitchType {

    public var density: EmbroideryDistance =  .mm(2)
    
    public var name: String = "Running Stitch"

    public func calcOps(withLength length: EmbroideryDistance, from position: EmbroideryPoint, facing angle: EmbroideryAngle, color: EmbroideryColor) -> BothOpTypes {
        var opsArray: [Operation] = []
        var renderingOpsArray: [RenderingOperation] = []
        
        let stitches = length.mm / density.mm
        var effectiveStitches = floor(stitches)
        
        if effectiveStitches == 0 {
            // if there are not enough length for one stitch interval just stitch once
            effectiveStitches = 1
        }
        
        let intStitches = Int(effectiveStitches)
        
        // interval between stitches. this is calculated as either the amount of stitches itself or the floor of the amount of stitches
        let interval = length.mm / effectiveStitches
        
        
        // figure out adding the stitches some other time
        var resultantPosition = position
        for _ in 0..<intStitches {
            let oldPosition = resultantPosition
            
            // add first move operation
            let firstOp = Operation(type: .move, at: resultantPosition)
            
            // calculate transforms
            let chgX = interval * cos(angle.radians)
            let chgY = interval * sin(angle.radians)
            
            // update resultant position
            resultantPosition.x += .mm(chgX)
            resultantPosition.y += .mm(chgY)
            
            // add second move operation
            let secondOp = Operation(type: .move, at: resultantPosition)
            
            opsArray.append(firstOp)
            opsArray.append(secondOp)
            
            renderingOpsArray.append(.line(oldPosition.toCanvasCoords(), resultantPosition.toCanvasCoords(), color.swiftUIColor))
        }
        
        return (ops: opsArray, renderingOps: renderingOpsArray)
    }
    
    public init(withStitchLength length: EmbroideryDistance) {
        self.density = length
    }
    
}
