//
//  EmbroideryThreadType.swift
//  BookCore
//
//  Created by Sean Wong on 24/5/23.
//

import Foundation
import UIKit
import SwiftUI

public typealias BothOpTypes = (ops: [Operation], renderingOps: [RenderingOperation])
//               ^ yes i know my naming is a bit bad sorry

public protocol StitchType {
    // Name of the thread type
    var name: String { get set }
    
    // Thread density
    var density: EmbroideryDistance { get set }
    
    // Ops required
    func calcOps(withLength length: EmbroideryDistance, from position: EmbroideryPoint, facing angle: EmbroideryAngle, color: EmbroideryColor) -> BothOpTypes
}
