//
//  EmbroideryAngle.swift
//  BianCore
//
//  Created by Jia Chen Yee on 19/2/23.
//

import Foundation

public struct EmbroideryAngle: ExpressibleByFloatLiteral, ExpressibleByIntegerLiteral, Hashable, Codable {
    
    public enum TurnDirection {
        case clockwise
        case counterClockwise
    }
    
    public var radians: Double
    
    public init(floatLiteral value: Double) {
        radians = value
    }
    
    public init(integerLiteral value: Double) {
        radians = value
    }
    
    public init(radians: Double) {
        self.radians = radians
    }
    
    public init(degrees: Double) {
        radians = degrees * .pi / 180
    }
    
    public var degrees: Double {
        get {
            return radians * 180 / .pi
        }
        set {
            radians = newValue * .pi / 180
        }
    }
    
    public static func degrees(_ value: Double) -> Self {
        return Self(degrees: value)
    }
    
    public static func degrees(_ value: Int) -> Self {
        return Self(degrees: Double(value))
    }
    
    public static func radians(_ value: Double) -> Self {
        return Self(radians: value)
    }
    
    public static func radians(_ value: Int) -> Self {
        return Self(radians: Double(value))
    }
}

postfix operator °
public postfix func °(_ value: Double) -> EmbroideryAngle {
    return EmbroideryAngle(degrees: value)
}
