//
//  EmbroideryAngle.swift
//  BianCore
//
//  Created by Jia Chen Yee on 19/2/23.
//

import Foundation

public struct EmbroideryAngle: ExpressibleByFloatLiteral, ExpressibleByIntegerLiteral, Hashable, Codable {
    
    public enum TurnDirection {
        case clockwise
        case counterClockwise
    }
    
    public var unnormalisedRadians: Double
    
    public var radians: Double {
        get {
            return EmbroideryAngle.norm(unnormalisedRadians)
        }
        set(newValue) {
            unnormalisedRadians = newValue
        }
    }
    
    public var degrees: Double {
        get {
            return radians * 180 / .pi
        }
        set {
            radians = newValue * .pi / 180
        }
    }
    
    public init(floatLiteral value: Double) {
        unnormalisedRadians = value
    }
    
    public init(integerLiteral value: Double) {
        unnormalisedRadians = value
    }
    
    public init(radians: Double) {
        unnormalisedRadians = radians
    }
    
    public init(degrees: Double) {
        unnormalisedRadians = degrees * .pi / 180
    }
    
    public var opposite: EmbroideryAngle {
        EmbroideryAngle(radians: radians - .pi)
    }
    
    public static func degrees(_ value: Double) -> Self {
        return Self(degrees: value)
    }
    
    public static func degrees(_ value: Int) -> Self {
        return Self(degrees: Double(value))
    }
    
    public static func radians(_ value: Double) -> Self {
        return Self(radians: value)
    }
    
    public static func radians(_ value: Int) -> Self {
        return Self(radians: Double(value))
    }
    
    /// Normalises the angle to be in the range `[0, 2pi)`
    private static func norm(_ value: Double) -> Double {
        var mod = value.remainder(dividingBy: 2 * .pi)
        
        if mod < 0 { mod += 2 * .pi }
        
        return mod
    }
}

postfix operator °
public postfix func °(_ value: Double) -> EmbroideryAngle {
    return EmbroideryAngle(degrees: value)
}
