//
//  EmbroideryPoint+VectorOperations.swift
//  BianCore
//
//  Created by T Krobot on 19/9/23.
//

import Foundation

// Credits https://github.com/koher/EmbroideryPointVector/blob/main/Sources/EmbroideryPointVector/EmbroideryPoint.swift

extension EmbroideryPoint {
    public func isNearlyEqual(to point: EmbroideryPoint, epsilon: EmbroideryDistance) -> Bool {
        let difference = self - point
        return abs(difference.x) < epsilon && abs(difference.y) < epsilon
    }
    
    public var length: EmbroideryDistance {
        return .mm(hypot(x.mm, y.mm))
    }
    
    public var squareLength: EmbroideryDistance {
        return x * x + y * y
    }
    
    public var unit: EmbroideryPoint {
        return self * (1.0 / length)
    }
    
    public var phase: EmbroideryAngle {
        return .init(radians: atan2(y.mm, x.mm))
    }
    
    public func distance(from point: EmbroideryPoint) -> EmbroideryDistance {
        return (self - point).length
    }
    
    public func squareDistance(from point: EmbroideryPoint) -> EmbroideryDistance {
        return (self - point).squareLength
    }
    
    public func angle(from point: EmbroideryPoint) -> EmbroideryAngle {
        return .init(radians: acos(cos(from: point).mm))
    }
    
    public func cos(from point: EmbroideryPoint) -> EmbroideryDistance {
        let squareLength1 = self.squareLength
        guard squareLength1 > 0.0 else { return 1.0 }
        let squareLength2 = point.squareLength
        guard squareLength2 > 0.0 else { return 1.0 }
        return Swift.min(Swift.max(self.dot(point) / sqrt(squareLength1 * squareLength2), -1.0), 1.0)
    }
    
    public func dot(_ other: EmbroideryPoint) -> EmbroideryDistance {
        return self.x * other.x + self.y * other.y
    }
}

extension EmbroideryPoint {
    public static prefix func + (value: EmbroideryPoint) -> EmbroideryPoint {
        return value
    }
    
    public static prefix func - (value: EmbroideryPoint) -> EmbroideryPoint {
        return EmbroideryPoint(x: -value.x, y: -value.y)
    }
    
    public static func + (lhs: EmbroideryPoint, rhs: EmbroideryPoint) -> EmbroideryPoint {
        return EmbroideryPoint(x: lhs.x + rhs.x, y: lhs.y + rhs.y)
    }
    
    public static func - (lhs: EmbroideryPoint, rhs: EmbroideryPoint) -> EmbroideryPoint {
        return EmbroideryPoint(x: lhs.x - rhs.x, y: lhs.y - rhs.y)
    }
    
    public static func * (lhs: EmbroideryPoint, rhs: EmbroideryPoint) -> EmbroideryPoint {
        return EmbroideryPoint(x: lhs.x * rhs.x, y: lhs.y * rhs.y)
    }
    
    public static func * (lhs: EmbroideryPoint, rhs: EmbroideryDistance) -> EmbroideryPoint {
        return EmbroideryPoint(x: lhs.x * rhs, y: lhs.y * rhs)
    }
    
    public static func * (lhs: EmbroideryDistance, rhs: EmbroideryPoint) -> EmbroideryPoint {
        return EmbroideryPoint(x: rhs.x * lhs, y: rhs.y * lhs)
    }
    
    public static func / (lhs: EmbroideryPoint, rhs: EmbroideryPoint) -> EmbroideryPoint {
        return EmbroideryPoint(x: lhs.x / rhs.x, y: lhs.y / rhs.y)
    }
    
    public static func / (lhs: EmbroideryPoint, rhs: EmbroideryDistance) -> EmbroideryPoint {
        return EmbroideryPoint(x: lhs.x / rhs, y: lhs.y / rhs)
    }
    
    public static func += (lhs: inout EmbroideryPoint, rhs: EmbroideryPoint) {
        lhs = lhs + rhs
    }
    
    public static func -= (lhs: inout EmbroideryPoint, rhs: EmbroideryPoint) {
        lhs = lhs - rhs
    }
    
    public static func *= (lhs: inout EmbroideryPoint, rhs: EmbroideryPoint) {
        lhs = lhs * rhs
    }
    
    public static func *= (lhs: inout EmbroideryPoint, rhs: EmbroideryDistance) {
        lhs = lhs * rhs
    }
    
    public static func /= (lhs: inout EmbroideryPoint, rhs: EmbroideryPoint) {
        lhs = lhs / rhs
    }
    
    public static func /= (lhs: inout EmbroideryPoint, rhs: EmbroideryDistance) {
        lhs = lhs / rhs
    }
}
