//
//  StraightStitch.swift
//  BianCore
//
//  Created by Sean Wong on 24/5/23.
//

import Foundation

public struct RunningStitch: StitchType {

    public var density: EmbroideryDistance =  .mm(2)
    
    public var name: String = "Running Stitch"

    public func calcOps(withLength length: EmbroideryDistance, from position: EmbroideryPoint, facing angle: EmbroideryAngle, color: EmbroideryColor) -> BothOpTypes {
       
        let (interval, numStitches) = StitchHelpers.calcIntervalAndNumStitches(density: density, length: length)
        
        let normOps = StitchHelpers.stitch(interval: interval, numStitches: numStitches, color: color)
        
        return StitchHelpers.transformOps(normOps, startingPoint: position, angle: angle)
    }
    
    public init(withStitchLength length: EmbroideryDistance) {
        self.density = length
    }
    
}
