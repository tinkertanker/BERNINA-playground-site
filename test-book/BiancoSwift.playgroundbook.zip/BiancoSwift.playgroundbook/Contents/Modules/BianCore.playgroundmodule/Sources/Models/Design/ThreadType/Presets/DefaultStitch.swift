//
//  DefaultStitch.swift
//  BianCore
//
//  Created by Sean Wong on 30/5/23.
//

import Foundation

public struct DefaultStitch: StitchType {
    
    // default run has no density
    public var density: EmbroideryDistance = .mm(0)
    
    public var name: String = "Default Stitch"
    
    public func calcOps(withLength length: EmbroideryDistance, from position: EmbroideryPoint, facing angle: EmbroideryAngle, color: EmbroideryColor) ->  BothOpTypes {
        var opsArray: [Operation] = []
        
        var resultantPosition = position
        // add first move operation
        opsArray.append(Operation(type: .move, at: resultantPosition))
        
        // calculate transforms
        let chgX = length.millimeters * cos(angle.radians)
        let chgY = length.millimeters * sin(angle.radians)
        
        // update resultant position
        resultantPosition.x += .mm(chgX)
        resultantPosition.y += .mm(chgY)
        
        // add second move operation
        opsArray.append(Operation(type: .move, at: resultantPosition))
        
        let renderingOps: [RenderingOperation] = [.line(position.toCanvasCoords(), resultantPosition.toCanvasCoords(), color.swiftUIColor)]
        
        return (ops: opsArray, renderingOps: renderingOps)
    }
    
}
