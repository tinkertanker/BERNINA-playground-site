//
//  EmbroideryDistance+Arithmetic.swift
//  BianCore
//
//  Created by Jia Chen Yee on 19/2/23.
//

import Foundation

extension EmbroideryDistance: Equatable, Comparable, FloatingPoint {
    public typealias Exponent = Int
    
    public var magnitude: Self {
        Self.millimeters(self.millimeters.magnitude)
    }
    
    public init(signOf value: Self, magnitudeOf magnitude: Self) {
        self.millimeters = Double(signOf: value.millimeters, magnitudeOf: magnitude.millimeters)
    }
    
    public init(_ value: Int) {
        self.millimeters = Double(value)
    }
    
    public init<Source>(_ value: Source) where Source : BinaryInteger {
        self.millimeters = Double(value)
    }
    
    public init?<Source>(exactly value: Source) where Source : BinaryInteger {
        guard let millimeters = Double(exactly: value) else {
            return nil
        }
        self.millimeters = millimeters
    }
    
    public static var radix: Int {
        return Double.radix
    }
    
    public static var greatestFiniteMagnitude: Self {
        return Self(millimeters: Double.greatestFiniteMagnitude)
    }
    
    public static var pi: Self {
        return Self.millimeters(.pi)
    }
    
    public var ulp: Self {
        return Self.millimeters(.ulpOfOne)
    }
    
    public static var leastNormalMagnitude: Self {
        return Self.millimeters(.leastNormalMagnitude)
    }
    
    public static var leastNonzeroMagnitude: Self {
        return Self.millimeters(.leastNonzeroMagnitude)
    }
    
    public mutating func formRemainder(dividingBy other: Self) {
        self.millimeters.formRemainder(dividingBy: other.millimeters)
    }
    
    public mutating func formTruncatingRemainder(dividingBy other: Self) {
        self.millimeters.formTruncatingRemainder(dividingBy: other.millimeters)
    }
    
    public mutating func formSquareRoot() {
        self.millimeters.formSquareRoot()
    }
    
    public mutating func addProduct(_ lhs: Self, _ rhs: Self) {
        self.millimeters.addProduct(lhs.millimeters, rhs.millimeters)
    }
    
    public func isLess(than other: Self) -> Bool {
        self < other
    }
    
    public func isLessThanOrEqualTo(_ other: Self) -> Bool {
        self <= other
    }
    
    public func isTotallyOrdered(belowOrEqualTo other: Self) -> Bool {
        millimeters.isTotallyOrdered(belowOrEqualTo: other.millimeters)
    }
    
    public var isInfinite: Bool {
        millimeters.isInfinite
    }
    
    public var isNaN: Bool {
        millimeters.isNaN
    }
    
    public typealias Magnitude = Self
    
    public static func + (lhs: Self, rhs: Self) -> Self {
        Self(millimeters: lhs.millimeters + rhs.millimeters)
    }
    
    public static func - (lhs: Self, rhs: Self) -> Self {
        Self(millimeters: lhs.millimeters - rhs.millimeters)
    }
    
    public static func * (lhs: Self, rhs: Self) -> Self {
        Self(millimeters: lhs.millimeters * rhs.millimeters)
    }
    
    public static func / (lhs: Self, rhs: Self) -> Self {
        Self(millimeters: lhs.millimeters / rhs.millimeters)
    }
    
    public static func == (lhs: Self, rhs: Self) -> Bool {
        lhs.millimeters == rhs.millimeters
    }
    
    public static func < (lhs: Self, rhs: Self) -> Bool {
        lhs.millimeters < rhs.millimeters
    }
    
    public static func > (lhs: Self, rhs: Self) -> Bool {
        lhs.millimeters > rhs.millimeters
    }
    
    public static func >= (lhs: Self, rhs: Self) -> Bool {
        lhs.millimeters >= rhs.millimeters
    }
    
    public static func <= (lhs: Self, rhs: Self) -> Bool {
        lhs.millimeters >= rhs.millimeters
    }
    
    public static var zero: Self {
        return Self.millimeters(0)
    }
    
    public func distance(to other: Self) -> Self {
        return Self(millimeters: other.millimeters - millimeters)
    }
    
    func advanced(by n: Double) -> Self {
        return Self(millimeters: millimeters + n)
    }
    
    public static func +=(lhs: inout Self, rhs: Self) {
        lhs.millimeters += rhs.millimeters
    }
    
    public static func -=(lhs: inout Self, rhs: Self) {
        lhs.millimeters -= rhs.millimeters
    }
    
    public static func *=(lhs: inout Self, rhs: Self) {
        lhs.millimeters *= rhs.millimeters
    }
    
    public static func /=(lhs: inout Self, rhs: Self) {
        lhs.millimeters /= rhs.millimeters
    }
    
    public static var nan: Self {
        return Self(millimeters: Double.nan)
    }
    
    public static var infinity: Self {
        return Self(millimeters: Double.infinity)
    }
    
    public static var signalingNaN: Self {
        return Self(millimeters: Double.signalingNaN)
    }
    
    public var isSignalingNaN: Bool {
        return millimeters.isSignalingNaN
    }
    
    public var isFinite: Bool {
        return millimeters.isFinite
    }
    
    public var isZero: Bool {
        return millimeters.isZero
    }
    
    public var isSubnormal: Bool {
        return millimeters.isSubnormal
    }
    
    public var isNormal: Bool {
        return millimeters.isNormal
    }
    
    public var isCanonical: Bool {
        return millimeters.isCanonical
    }
    
    public var binade: Self {
        return Self(millimeters: millimeters.binade)
    }
    
    public var significandWidth: Int {
        return millimeters.significandWidth
    }
    
    public func advanced(by n: Self) -> Self {
        return Self(millimeters: millimeters.advanced(by: n.millimeters))
    }
    
    public func isEqual(to other: Self) -> Bool {
        return millimeters.isEqual(to: other.millimeters)
    }
    
    public var nextUp: Self {
        return Self(millimeters: millimeters.nextUp)
    }
    
    public var nextDown: Self {
        return Self(millimeters: millimeters.nextDown)
    }
    
    public var sign: FloatingPointSign {
        return millimeters.sign
    }
    
    public var exponent: Exponent {
        return millimeters.exponent
    }
    
    public var significand: Self {
        return Self(millimeters: millimeters.significand)
    }
    
    public init(sign: FloatingPointSign, exponent: Exponent, significand: Self) {
        self.millimeters = Double(sign: sign, exponent: exponent, significand: significand.millimeters)
    }
    
    public mutating func round(_ rule: FloatingPointRoundingRule) {
        millimeters.round(rule)
    }
    
    public mutating func round() {
        millimeters.round()
    }
    
    public mutating func round(_ rule: FloatingPointRoundingRule, increment: Self) {
        millimeters.round(rule)
    }
    
    public func addingProduct(_ lhs: Self, _ rhs: Self) -> Self {
        return Self(millimeters: millimeters.addingProduct(lhs.millimeters, rhs.millimeters))
    }
    
    public func squareRoot() -> Self {
        return Self(millimeters: millimeters.squareRoot())
    }
    
    public func rounded(_ rule: FloatingPointRoundingRule) -> Self {
        return Self(millimeters: millimeters.rounded(rule))
    }
    
    public func rounded() -> Self {
        return Self(millimeters: millimeters.rounded())
    }
    
    public func rounded(_ rule: FloatingPointRoundingRule, increment: Self) -> Self {
        return Self(millimeters: millimeters.rounded(rule) + increment.millimeters)
    }
    
    public func truncatingRemainder(dividingBy other: Self) -> Self {
        return Self(millimeters: millimeters.truncatingRemainder(dividingBy: other.millimeters))
    }
    
    public func remainder(dividingBy other: Self) -> Self {
        return Self(millimeters: millimeters.remainder(dividingBy: other.millimeters))
    }
    
    public func adding(_ other: Self) -> Self {
        return Self(millimeters: millimeters + other.millimeters)
    }
    
    public func subtracting(_ other: Self) -> Self {
        return Self(millimeters: millimeters - other.millimeters)
    }
    
    public func multiplied(by other: Self) -> Self {
        return Self(millimeters: millimeters * other.millimeters)
    }
    
    public func divided(by other: Self) -> Self {
        return Self(millimeters: millimeters / other.millimeters)
    }
}
