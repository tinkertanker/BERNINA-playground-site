//
//  CrossStitch.swift
//  BianCore
//
//  Created by T Krobot on 20/9/23.
//

import Foundation

public struct ZigZagStitch: StitchType {
    public var name: String = "ZigZag Stitch"
    
    public var density: EmbroideryDistance = .mm(5)
    public var width: EmbroideryDistance = .mm(5)
    
    public init(density: EmbroideryDistance, width: EmbroideryDistance) {
        self.density = density
        self.width = width
    }
    public init(density: Double, width: Double) {
        self.density = .mm(density)
        self.width = .mm(width)
    }
    public init(density: Int, width: Int) {
        self.density = .mm(density)
        self.width = .mm(width)
    }
    
    public func calcOps(withLength length: EmbroideryDistance, from position: EmbroideryPoint, facing angle: EmbroideryAngle, color: EmbroideryColor) -> BothOpTypes {
        
        let (interval, numStitches) = StitchHelpers.calcIntervalAndNumStitches(density: density, length: length, minNumStitches: 2)
        
        let trianglesStart = EmbroideryPoint(x: interval/2, y: -width / 2)
        
        let firstHalfMove = StitchHelpers.moveOps(from: .zero, to: trianglesStart, color: color)
        
        let normTriangles = StitchHelpers.triangleStitch(
            interval: interval,
            width: width,
            numStitches: numStitches - 1,
            firstStroke: 1,
            color: color
        )
        
        let triangles = StitchHelpers.transformOps(normTriangles, startingPoint: trianglesStart, angle: .zero)
        
        let nextStartingPos = triangles.ops.last!.embroideryPoint
        
        let lastHalfMove = StitchHelpers.moveOps(from: nextStartingPos, to: .init(x: length , y: 0), color: color)
        
        let normOps = firstHalfMove + triangles + lastHalfMove
        
        return StitchHelpers.transformOps(normOps, startingPoint: position, angle: angle)
    }
    
    
}
