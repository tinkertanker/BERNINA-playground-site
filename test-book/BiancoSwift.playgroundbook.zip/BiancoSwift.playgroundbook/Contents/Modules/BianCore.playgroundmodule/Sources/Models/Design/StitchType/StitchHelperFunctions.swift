//
//  StitchHelperFunctions.swift
//  BianCore
//
//  Created by T Krobot on 20/9/23.
//
//  Abstract: Helper functions for use in StitchType implementations

import Foundation
import SwiftUI

enum StitchHelpers {
    static func moveOps(from: EmbroideryPoint, to: EmbroideryPoint, color: EmbroideryColor) -> BothOpTypes {
        return (
            ops: [
                Operation(type: .move, at: from),
                Operation(type: .move, at: to)
            ],
            renderingOps: [
                .line(from.toCanvasCoords(), to.toCanvasCoords(), color.swiftUIColor)
            ]
        )
    }
    
    static func calcIntervalAndNumStitches(density: EmbroideryDistance, length: EmbroideryDistance, minNumStitches: Int = 1) -> (interval: EmbroideryDistance, numStitches: Int) {
        let stitches = length.mm / density.mm
        var effectiveStitches = floor(stitches)
        
        if effectiveStitches < Double(minNumStitches) {
            // if there are not enough length for one stitch interval just stitch once
            effectiveStitches = Double(minNumStitches)
        }
        
        let intStitches = Int(effectiveStitches)
        
        // interval between stitches. this is calculated as either the amount of stitches itself or the floor of the amount of stitches
        let interval: EmbroideryDistance = .mm(length.mm / effectiveStitches)
        
        return (interval: interval, numStitches: intStitches)
    }
        
    /// Draws a stitch at regular intervals.
    /// > Important: Stitch is drawn assuming starting at (0, 0) towards the right. Angle and positioning can be handled afterwards with ``transformOps(_:startingPoint:angle:)``.
    static func stitch(interval: EmbroideryDistance, numStitches: Int, color: EmbroideryColor) -> BothOpTypes {
        var opsArray: [Operation] = []
        var renderingOpsArray: [RenderingOperation] = []
        
        // figure out adding the stitches some other time
        var resultantPosition: EmbroideryPoint = .zero
        for _ in 0..<numStitches {
            let oldPosition = resultantPosition
            
            // add first move operation
            let firstOp = Operation(type: .move, at: resultantPosition)
            
            // calculate transforms
            let chgX = interval.mm // * cos(angle.radians)
            let chgY = 0 // interval.mm * sin(angle.radians)
            
            // update resultant position
            resultantPosition.x += .mm(chgX)
            resultantPosition.y += .mm(chgY)
            
            // add second move operation
            let secondOp = Operation(type: .move, at: resultantPosition)
            
            opsArray.append(firstOp)
            opsArray.append(secondOp)
            
            renderingOpsArray.append(.line(oldPosition.toCanvasCoords(), resultantPosition.toCanvasCoords(), color.swiftUIColor))
        }
        
        return (ops: opsArray, renderingOps: renderingOpsArray)
    }
    
    /// Draws a triangle like pattern.
    ///
    /// - Parameter firstStroke: has to be an integer 1 or -1 representing if the first stroke will be "down" or "up"
    /// > Important: Stitch is drawn assuming starting at (0, 0) towards the right. Angle and positioning can be handled afterwards with ``transformOps(_:startingPoint:angle:)``.
    static func triangleStitch(interval: EmbroideryDistance, width: EmbroideryDistance, numStitches: Int, firstStroke: Int, color: EmbroideryColor) -> BothOpTypes {
        var opsArray: [Operation] = []
        var renderingOpsArray: [RenderingOperation] = []
        
        assert(firstStroke == -1 || firstStroke == 1)
        
        var oldPosition: EmbroideryPoint = .zero
        // first run to the right
        for i in 1...numStitches {
            let newXpos = Double(i) * interval.mm
            let newYpos = (i % 2 == 1 ? Double(firstStroke) * width.mm : 0.0)
            let newPosition = EmbroideryPoint(x: newXpos, y: newYpos)
            
            opsArray.append(contentsOf: [
                Operation(type: .move, at: oldPosition),
                Operation(type: .move, at: newPosition)
            ])
            renderingOpsArray.append(.line(oldPosition.toCanvasCoords(), newPosition.toCanvasCoords(), color.swiftUIColor))
            
            oldPosition = newPosition
        }
        
        return (ops: opsArray, renderingOps: renderingOpsArray)
    }
    
    /// Transforms the normalised ops assuming starting position of (0, 0) and angle of zero (towards the right) into actual coordinates
    static func transformOps(_ normOps: BothOpTypes, startingPoint: EmbroideryPoint, angle: EmbroideryAngle) -> BothOpTypes {
        let startingCGPoint = CGPoint(x: startingPoint.x.mm, y: startingPoint.y.mm)
        let opAffineTransform = CGAffineTransform(translationX: startingCGPoint.x, y: startingCGPoint.y).rotated(by: angle.radians)
        
        let renderingOpAffineTransform = CGAffineTransform(translationX: startingPoint.toCanvasCoords().x, y: startingPoint.toCanvasCoords().y).rotated(by: angle.radians)
        
        let newOps: [Operation] = normOps.ops.map { op in
            let transformedPt = op.cgPoint.applying(opAffineTransform)
            
            return Operation(
                type: op.type,
                at: EmbroideryPoint(x: transformedPt.x, y: transformedPt.y),
                color: op.color
            )
        }
        
        let newRenderingOps: [RenderingOperation] = normOps.renderingOps.map { renderingOp in
            switch renderingOp {
            case .line(let from, let to, let color):
                return .line(from.applying(renderingOpAffineTransform), to.applying(renderingOpAffineTransform), color)
            case .jump(let from, let to):
                return .jump(from.applying(renderingOpAffineTransform), to.applying(renderingOpAffineTransform))
            case .turn(let from, let to):
                return .turn(from + angle.swiftUIAngle, to + angle.swiftUIAngle)
            }
        }
        
        return (ops: newOps, renderingOps: newRenderingOps)
    }
}

extension Angle {
    static func +(lhs: Angle, rhs: Angle) -> Angle {
        Self(radians: lhs.radians + rhs.radians)
    }
}
