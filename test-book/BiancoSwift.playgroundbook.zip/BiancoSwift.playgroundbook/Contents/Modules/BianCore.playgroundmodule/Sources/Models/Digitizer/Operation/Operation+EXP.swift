//
//  Operation+EXP.swift
//  BERNINA
//
//  Created by Jia Chen Yee on 8/10/22.
//

import Foundation
import UIKit

extension Collection where Element == [Operation] {
    func getDigitizerOutput() -> DigitizerOutput {
        DigitizerOutput(exp: Data(toEXP()),
                        inf: toINF())
    }
    
    func toINF() -> Data {
        
        var data = Data()
        
        let threads = self.compactMap { operations in
            operations.compactMap { $0.color }.first
        }
        
        for (offset, thread) in threads.enumerated() {
            data.append(contentsOf: thread.toINF(sequence: UInt8(offset)))
        }
        
        var header: [UInt8] = [0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00]
        
        header.append(UInt8(0x00)) // data.count + header.count - 2
        header.append(contentsOf: [0x00, 0x00, 0x00])
        header.append(UInt8(threads.count))
        
        data.insert(contentsOf: header, at: 0)
        
        return data
    }
    
    func toEXP() -> [UInt8] {
        var expArray = [0x00, 0x00]
        
        var origin: (Double, Double)
        let scale = 10.0
        
        func move(x: Int, y: Int) {
            var yy = Double(y * -1);
            var xx = Double(x);
            if (xx < 0) { xx += 256 }
            expArray.append(Int(round(xx)))
            if (yy < 0) { yy += 256 }
            expArray.append(Int(round(yy)))
        }
        
        for (offset, i) in self.enumerated() {
            
            let start = i[0]
            
            guard start.type != .colorChange else {
                if offset != 0 {
                    expArray.append(contentsOf: start.type.expEquivalent())
                }
                continue
            }
            
            let end = i[1]
            
            origin = (start.cord[0] * scale, start.cord[1] * scale)
            
            let x1 = round(end.cord[0] * scale) - origin.0
            let y1 = round(end.cord[1] * scale) - origin.1
            let x0 = round(start.cord[0] * scale) - origin.0
            let y0 = round(start.cord[1] * scale) - origin.1
            
            var sumX: Double = 0
            var sumY: Double = 0
            
            let dmax = Swift.max(Double(abs(x1 - x0)), Double(abs(y1 - y0)))
            
            let dsteps = abs(dmax / 127)
            
            if (dsteps <= 1) {
                expArray.append(contentsOf: start.type.expEquivalent())
                
                move(x: Int(round(x1 - x0)), y: Int(round(y1 - y0)))
            } else {
                for j in 0...Int(dsteps.rounded(.up) - 1) {
                    expArray.append(contentsOf: start.type.expEquivalent())
                    
                    if (j < Int(dsteps.rounded(.up)) - 1) {
                        move(x: Int((x1 - x0)/dsteps), y: Int((y1 - y0)/dsteps))
                        sumX += (x1 - x0)/dsteps
                        sumY += (y1 - y0)/dsteps
                    } else {
                        move(x: Int(round(x1 - x0 - sumX)), y: Int(round(y1 - y0 - sumY)))
                    }
                }
            }
        }
        
        let uIntArray: [UInt8] = expArray.map(UInt8.init) + [0x00, 0x00]
        return uIntArray
    }

}
