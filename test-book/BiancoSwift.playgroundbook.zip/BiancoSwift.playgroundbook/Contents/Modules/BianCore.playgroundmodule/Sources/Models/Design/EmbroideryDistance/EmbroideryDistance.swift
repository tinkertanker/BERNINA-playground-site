//
//  EmbroideryDistance.swift
//  BiancoCore
//
//  Created by Jia Chen Yee on 19/2/23.
//

import Foundation

public struct EmbroideryDistance: ExpressibleByFloatLiteral, ExpressibleByIntegerLiteral, Hashable, CustomStringConvertible, Codable {
    public var millimeters: Double
    
    public var mm: Double {
        get { millimeters }
        set { millimeters = newValue }
    }
    
    public var centimeters: Double {
        get {
            return millimeters / 10
        }
        set {
            millimeters = newValue * 10
        }
    }
    
    public var cm: Double {
        get {
            return millimeters / 10
        }
        set {
            millimeters = newValue * 10
        }
    }
    
    public init(floatLiteral value: Double) {
        millimeters = value
    }
    
    public init(integerLiteral value: Int) {
        millimeters = Double(value)
    }
    
    public init(millimeters: Double) {
        self.millimeters = millimeters
    }
    
    public init(centimeters: Double) {
        millimeters = centimeters * 10
    }
    
    public init(mm: Double) {
        self.millimeters = mm
    }
    
    public init(cm: Double) {
        millimeters = cm * 10
    }
    
    public static func centimeters(_ value: Double) -> Self {
        return Self(centimeters: value)
    }
    
    public static func millimeters(_ value: Double) -> Self {
        return Self(millimeters: value)
    }
    
    public static func cm(_ value: Double) -> Self {
        return Self(centimeters: value)
    }
    
    public static func mm(_ value: Double) -> Self {
        return Self(millimeters: value)
    }
    
    public static func mm(_ value: Int) -> Self {
        return Self(millimeters: Double(value))
    }
    
    public var description: String {
        "\(mm)mm"
    }
}
