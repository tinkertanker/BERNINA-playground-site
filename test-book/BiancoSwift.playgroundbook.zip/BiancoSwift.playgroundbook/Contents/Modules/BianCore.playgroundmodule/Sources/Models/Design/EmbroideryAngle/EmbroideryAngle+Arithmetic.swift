//
//  EmbroideryAngle+Arithmetic.swift
//  BianCore
//
//  Created by Jia Chen Yee on 19/2/23.
//

import Foundation

extension EmbroideryAngle: Equatable, Comparable, FloatingPoint {
    public typealias Exponent = Int
    
    public var magnitude: EmbroideryAngle {
        Self.radians(self.radians.magnitude)
    }
    
    public init(signOf value: EmbroideryAngle, magnitudeOf magnitude: EmbroideryAngle) {
        self.radians = Double(signOf: value.radians, magnitudeOf: magnitude.radians)
    }
    
    public init(_ value: Int) {
        self.radians = Double(value)
    }
    
    public init<Source>(_ value: Source) where Source : BinaryInteger {
        self.radians = Double(value)
    }
    
    public init?<Source>(exactly value: Source) where Source : BinaryInteger {
        guard let radians = Double(exactly: value) else {
            return nil
        }
        self.radians = radians
    }
    
    public static var radix: Int {
        return Double.radix
    }
    
    public static var greatestFiniteMagnitude: EmbroideryAngle {
        return EmbroideryAngle(radians: Double.greatestFiniteMagnitude)
    }
    
    public static var pi: EmbroideryAngle {
        return EmbroideryAngle.radians(.pi)
    }
    
    public var ulp: EmbroideryAngle {
        return EmbroideryAngle.radians(.ulpOfOne)
    }
    
    public static var leastNormalMagnitude: EmbroideryAngle {
        return EmbroideryAngle.radians(.leastNormalMagnitude)
    }
    
    public static var leastNonzeroMagnitude: EmbroideryAngle {
        return EmbroideryAngle.radians(.leastNonzeroMagnitude)
    }
    
    public mutating func formRemainder(dividingBy other: EmbroideryAngle) {
        self.radians.formRemainder(dividingBy: other.radians)
    }
    
    public mutating func formTruncatingRemainder(dividingBy other: EmbroideryAngle) {
        self.radians.formTruncatingRemainder(dividingBy: other.radians)
    }
    
    public mutating func formSquareRoot() {
        self.radians.formSquareRoot()
    }
    
    public mutating func addProduct(_ lhs: EmbroideryAngle, _ rhs: EmbroideryAngle) {
        self.radians.addProduct(lhs.radians, rhs.radians)
    }
    
    public func isLess(than other: EmbroideryAngle) -> Bool {
        self < other
    }
    
    public func isLessThanOrEqualTo(_ other: EmbroideryAngle) -> Bool {
        self <= other
    }
    
    public func isTotallyOrdered(belowOrEqualTo other: EmbroideryAngle) -> Bool {
        radians.isTotallyOrdered(belowOrEqualTo: other.radians)
    }
    
    public var isInfinite: Bool {
        radians.isInfinite
    }
    
    public var isNaN: Bool {
        radians.isNaN
    }
    
    public typealias Magnitude = Self
    
    public static func + (lhs: EmbroideryAngle, rhs: EmbroideryAngle) -> EmbroideryAngle {
        Self(radians: lhs.radians + rhs.radians)
    }
    
    public static func - (lhs: EmbroideryAngle, rhs: EmbroideryAngle) -> EmbroideryAngle {
        Self(radians: lhs.radians - rhs.radians)
    }
    
    public static func * (lhs: EmbroideryAngle, rhs: EmbroideryAngle) -> EmbroideryAngle {
        Self(radians: lhs.radians * rhs.radians)
    }
    
    public static func / (lhs: EmbroideryAngle, rhs: EmbroideryAngle) -> EmbroideryAngle {
        Self(radians: lhs.radians / rhs.radians)
    }
    
    public static func == (lhs: EmbroideryAngle, rhs: EmbroideryAngle) -> Bool {
        lhs.radians == rhs.radians
    }
    
    public static func < (lhs: EmbroideryAngle, rhs: EmbroideryAngle) -> Bool {
        lhs.radians < rhs.radians
    }
    
    public static func > (lhs: EmbroideryAngle, rhs: EmbroideryAngle) -> Bool {
        lhs.radians > rhs.radians
    }
    
    public static func >= (lhs: EmbroideryAngle, rhs: EmbroideryAngle) -> Bool {
        lhs.radians >= rhs.radians
    }
    
    public static func <= (lhs: EmbroideryAngle, rhs: EmbroideryAngle) -> Bool {
        lhs.radians >= rhs.radians
    }
    
    public static var zero: Self {
        return Self.radians(0)
    }
    
    public func distance(to other: EmbroideryAngle) -> EmbroideryAngle {
        return EmbroideryAngle(radians: other.radians - radians)
    }
    
    func advanced(by n: Double) -> EmbroideryAngle {
        return EmbroideryAngle(radians: radians + n)
    }
    
    public static func +=(lhs: inout EmbroideryAngle, rhs: EmbroideryAngle) {
        lhs.radians += rhs.radians
    }
    
    public static func -=(lhs: inout EmbroideryAngle, rhs: EmbroideryAngle) {
        lhs.radians -= rhs.radians
    }
    
    public static func *=(lhs: inout EmbroideryAngle, rhs: EmbroideryAngle) {
        lhs.radians *= rhs.radians
    }
    
    public static func /=(lhs: inout EmbroideryAngle, rhs: EmbroideryAngle) {
        lhs.radians /= rhs.radians
    }
    
    public static var nan: EmbroideryAngle {
        return EmbroideryAngle(radians: Double.nan)
    }
    
    public static var infinity: EmbroideryAngle {
        return EmbroideryAngle(radians: Double.infinity)
    }
    
    public static var signalingNaN: EmbroideryAngle {
        return EmbroideryAngle(radians: Double.signalingNaN)
    }
    
    public var isSignalingNaN: Bool {
        return radians.isSignalingNaN
    }
    
    public var isFinite: Bool {
        return radians.isFinite
    }
    
    public var isZero: Bool {
        return radians.isZero
    }
    
    public var isSubnormal: Bool {
        return radians.isSubnormal
    }
    
    public var isNormal: Bool {
        return radians.isNormal
    }
    
    public var isCanonical: Bool {
        return radians.isCanonical
    }
    
    public var binade: EmbroideryAngle {
        return EmbroideryAngle(radians: radians.binade)
    }
    
    public var significandWidth: Int {
        return radians.significandWidth
    }
    
    public func advanced(by n: EmbroideryAngle) -> EmbroideryAngle {
        return EmbroideryAngle(radians: radians.advanced(by: n.radians))
    }
    
    public func isEqual(to other: EmbroideryAngle) -> Bool {
        return radians.isEqual(to: other.radians)
    }
    
    public var nextUp: EmbroideryAngle {
        return EmbroideryAngle(radians: radians.nextUp)
    }
    
    public var nextDown: EmbroideryAngle {
        return EmbroideryAngle(radians: radians.nextDown)
    }
    
    public var sign: FloatingPointSign {
        return radians.sign
    }
    
    public var exponent: Exponent {
        return radians.exponent
    }
    
    public var significand: EmbroideryAngle {
        return EmbroideryAngle(radians: radians.significand)
    }
    
    public init(sign: FloatingPointSign, exponent: Exponent, significand: EmbroideryAngle) {
        self.radians = Double(sign: sign, exponent: exponent, significand: significand.radians)
    }
    
    public mutating func round(_ rule: FloatingPointRoundingRule) {
        radians.round(rule)
    }
    
    public mutating func round() {
        radians.round()
    }
    
    public mutating func round(_ rule: FloatingPointRoundingRule, increment: EmbroideryAngle) {
        radians.round(rule)
    }
    
    public func addingProduct(_ lhs: EmbroideryAngle, _ rhs: EmbroideryAngle) -> EmbroideryAngle {
        return EmbroideryAngle(radians: radians.addingProduct(lhs.radians, rhs.radians))
    }
    
    public func squareRoot() -> EmbroideryAngle {
        return EmbroideryAngle(radians: radians.squareRoot())
    }
    
    public func rounded(_ rule: FloatingPointRoundingRule) -> EmbroideryAngle {
        return EmbroideryAngle(radians: radians.rounded(rule))
    }
    
    public func rounded() -> EmbroideryAngle {
        return EmbroideryAngle(radians: radians.rounded())
    }
    
    public func rounded(_ rule: FloatingPointRoundingRule, increment: EmbroideryAngle) -> EmbroideryAngle {
        return EmbroideryAngle(radians: radians.rounded(rule) + increment.radians)
    }
    
    public func truncatingRemainder(dividingBy other: EmbroideryAngle) -> EmbroideryAngle {
        return EmbroideryAngle(radians: radians.truncatingRemainder(dividingBy: other.radians))
    }
    
    public func remainder(dividingBy other: EmbroideryAngle) -> EmbroideryAngle {
        return EmbroideryAngle(radians: radians.remainder(dividingBy: other.radians))
    }
    
    public func adding(_ other: EmbroideryAngle) -> EmbroideryAngle {
        return EmbroideryAngle(radians: radians + other.radians)
    }
    
    public func subtracting(_ other: EmbroideryAngle) -> EmbroideryAngle {
        return EmbroideryAngle(radians: radians - other.radians)
    }
    
    public func multiplied(by other: EmbroideryAngle) -> EmbroideryAngle {
        return EmbroideryAngle(radians: radians * other.radians)
    }
    
    public func divided(by other: EmbroideryAngle) -> EmbroideryAngle {
        return EmbroideryAngle(radians: radians / other.radians)
    }
}
