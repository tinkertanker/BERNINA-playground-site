//
//  EmbroideryColor.swift
//  BianCore
//
//  Created by Jia Chen Yee on 19/2/23.
//

import Foundation
import UIKit
import SwiftUI

public struct EmbroideryColor: Equatable, Codable, CustomPlaygroundDisplayConvertible {
    
    public var playgroundDescription: Any {
        return uiColor
    }
    
    var name: String
    
    var red: Double
    var green: Double
    var blue: Double
    
    var swiftUIColor: Color {
        Color(red: red / 255, green: green / 255, blue: blue / 255)
    }
    
    var uiColor: UIColor {
        UIColor(red: red / 255, green: green / 255, blue: blue / 255, alpha: 1)
    }
    
    init(name: String, red: Double, green: Double, blue: Double) {
        self.name = name
        self.red = red
        self.green = green
        self.blue = blue
    }
    
    func toINF(sequence: UInt8) -> Data {
        
        var data = Data()
        data.append(0x00)
        
        data.append(0x00)
        data.append(sequence + 1)
        data.append(UInt8(red))
        data.append(UInt8(green))
        data.append(UInt8(blue))
        data.append(0x00)
        data.append(UInt8(1))
        data.append(Data("BERNINA".utf8))
        data.append(0x00)
        data.append(Data(name.utf8))
        data.append(0x00)
        
        data.insert(UInt8(data.count + 1), at: 1)
        
        return data
    }
}
