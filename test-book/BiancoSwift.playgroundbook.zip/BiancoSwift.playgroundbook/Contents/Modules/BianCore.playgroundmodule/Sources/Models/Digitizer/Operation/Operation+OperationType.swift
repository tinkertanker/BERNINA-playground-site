//
//  Operation+OperationType.swift
//  BERNINA
//
//  Created by Jia Chen Yee on 8/10/22.
//

import Foundation

extension Operation {
    enum OperationType: Codable {
        case jump
        case move
        case colorChange
        
        func expEquivalent() -> [Int] {
            switch self {
            case .jump: return [0x80, 0x04]
            case .move: return []
            case .colorChange: return [0x80, 0x01, 0x00, 0x00]
            }
        }
    }
}
