//
//  DigitizerOutput.swift
//  BERNINA
//
//  Created by Jia Chen Yee on 8/10/22.
//

import Foundation

struct DigitizerOutput {
    var exp: Data
    var inf: Data
    
    var totalData: Data {
        var exp = exp
        exp.append(inf)
        return exp
    }
}
