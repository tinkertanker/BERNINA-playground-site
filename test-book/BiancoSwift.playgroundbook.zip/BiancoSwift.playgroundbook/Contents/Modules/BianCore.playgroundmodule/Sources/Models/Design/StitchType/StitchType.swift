//
//  EmbroideryThreadType.swift
//  BookCore
//
//  Created by Sean Wong on 24/5/23.
//

import Foundation
import UIKit
import SwiftUI

public typealias BothOpTypes = (ops: [Operation], renderingOps: [RenderingOperation])
//               ^ yes i know my naming is a bit bad sorry

public func + (lhs: BothOpTypes, rhs: BothOpTypes) -> BothOpTypes {
    return (ops: lhs.ops + rhs.ops, renderingOps: lhs.renderingOps + rhs.renderingOps)
}

public protocol StitchType {
    // Name of the thread type
    var name: String { get set }
    
    // Ops required
    func calcOps(withLength length: EmbroideryDistance, from position: EmbroideryPoint, facing angle: EmbroideryAngle, color: EmbroideryColor) -> BothOpTypes
}
