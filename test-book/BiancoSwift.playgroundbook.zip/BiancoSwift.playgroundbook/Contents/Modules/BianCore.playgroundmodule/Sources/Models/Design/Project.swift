//
//  Project.swift
//  BianCore
//
//  Created by Jia Chen Yee on 19/2/23.
//

import Foundation
import UIKit
import SwiftUI

/// Main class responsibile for keeping track of state and generating the list of ``Operation``s and ``RenderingOperation``s.
/// The ``Operation``s will be appended to ``operations`` and kept as state in the class, whereas the ``RenderingOperation``s will be returned from the function to be animated / drawn to the screen
///
/// > Note: ``Operation``s are for the embroidary machine (to be converted into .exp files), whereas ``RenderingOperation``s are for the live view to animate and draw
public class Project: CustomPlaygroundDisplayConvertible {
    
    // MARK: - Constants (starting state)
    static let startingAngle: EmbroideryAngle = .zero
    static let startingPosition: EmbroideryPoint = .init(x: 50, y: 65)
    static let startingColor: EmbroideryColor = .red
    
    
    // MARK: - State
    
    // Note: this could just be a flattened array of ops [Operation]
    //       but we use another nested array to group one "method"'s operations together.
    // E.g. moveForward() can generate multiple `Operations`s because of the different stich types.
    // Honestly not sure why jiachen did that but it works
    public var operations: [[Operation]] = [] // this is public for debugging purposes so i can inspect the operations
    
    // Current State
    var currentStitch: StitchType = DefaultStitch()
    var currentAngle = Project.startingAngle
    var currentPosition = Project.startingPosition
    var currentColor = Project.startingColor
    
    public init() {
        changeColor(to: currentColor)
    }
    
    // MARK: - Public API
    
    @discardableResult
    public func move(by distance: EmbroideryDistance) -> [RenderingOperation] {
        
        guard !distance.isZero else { return [] }
        
        // generate new ops
        let (newOps, newRenderingOps) = currentStitch.calcOps(withLength: distance, from: currentPosition, facing: currentAngle, color: currentColor)
        
        // update state
        guard let newPos = newOps.last else { return [] }
        currentPosition = newPos.last!.embroideryPoint
        
        operations.append(contentsOf: newOps)
        
        return newRenderingOps
    }

    @discardableResult
    public func move(to point: EmbroideryPoint) -> [RenderingOperation] {
        let a = point.x - currentPosition.x
        let b = point.y - currentPosition.y
        let distance = (a*a + b*b).squareRoot()
        
        let turnOps = self.turn(toFace: point)
        let moveOps = self.move(by: distance)
        
        return turnOps + moveOps
    }
    
    // FIXME: there's a bug here causes the radius to be slightly off especially for large step size
    //FIXED: DO NOT TOUCH ANYMORE 
    @discardableResult
    public func arc(_ direction: EmbroideryAngle.TurnDirection, radius: EmbroideryDistance, angle: EmbroideryAngle, stepSize: EmbroideryDistance = .mm(2)) -> [RenderingOperation] {
        
        var last_pos = currentPosition
        var renderingOps: [RenderingOperation] = []
        
        // split the *arc* length into equally spaced intervals acrodding to the step size
        let arcLength = EmbroideryDistance(mm: radius.mm * angle.unnormalisedRadians)
        let (arcInterval, numSteps) = StitchHelpers.calcIntervalAndNumStitches(density: stepSize, length: arcLength)
        // the angle subtended by each arcInterval
        let angleInterval = arcInterval.mm / radius.mm
        var centre = currentPosition
        // the actual distance you need to move is slightly smaller than the arc length
        // so we have to calculate this using cosine rule
        let moveInterval = 2.squareRoot() * radius.mm * (1 - cos(angleInterval)).squareRoot()
        //Don't touch this code, it's very complicated and hard to fix
        if direction == .counterClockwise {
            let offset_y = (-cos(-angle.unnormalisedRadians + currentAngle.unnormalisedRadians) + cos(currentAngle.unnormalisedRadians)) * radius.mm
//            let offset_y = cos(currentAngle.unnormalisedRadians) * radius.mm

            last_pos.y -= EmbroideryDistance(mm:offset_y)
            let offset_x = (-sin(-angle.unnormalisedRadians + currentAngle.unnormalisedRadians) + sin(currentAngle.unnormalisedRadians)) * radius.mm
//            let offset_x = sin(currentAngle.unnormalisedRadians) * radius.mm
            last_pos.x += EmbroideryDistance(mm:offset_x)
        } else {
            let offset_y = (cos(angle.unnormalisedRadians + currentAngle.unnormalisedRadians) - cos(currentAngle.unnormalisedRadians)) * radius.mm
            last_pos.y -= EmbroideryDistance(mm:offset_y)
            let offset_x = (sin(angle.unnormalisedRadians + currentAngle.unnormalisedRadians) - sin(currentAngle.unnormalisedRadians)) * radius.mm
            last_pos.x += EmbroideryDistance(mm:offset_x)
        }
        
        
        
        for i in 1...(numSteps - 1) {
            // the first and last turn should be half the angle so the circle isn't offset
            renderingOps.append(contentsOf: turn(direction, by: EmbroideryAngle(radians: i == 1 ? angleInterval/2 : angleInterval)))
            renderingOps.append(contentsOf: move(by: EmbroideryDistance(mm: moveInterval)))
        }
        renderingOps.append(contentsOf: turn(toFace: last_pos))
        renderingOps.append(contentsOf: move(to: last_pos))
        
        
        return renderingOps
        /*
        var renderingOps: [RenderingOperation] = []
        
        var n : EmbroideryAngle = 0
        while n < floor(angle/EmbroideryAngle(10)){
            renderingOps.append(contentsOf: turn(direction, by: EmbroideryAngle(degrees: 5)))
            renderingOps.append(contentsOf: move(by: EmbroideryDistance(mm: radius.mm * 0.174532)))
            renderingOps.append(contentsOf: turn(direction, by: EmbroideryAngle(degrees: 5)))
        }
        if Int(angle.degrees) % 10 != 0{
            renderingOps.append(contentsOf: turn(direction, by: EmbroideryAngle(degrees: Double((Int(angle.degrees) % 10))/2.0)))
            renderingOps.append(contentsOf: move(by: EmbroideryDistance(mm: (radius.mm * 0.174532) / (10.0 / Double(Int(angle.degrees) % 10)))) )))
            renderingOps.append(contentsOf: turn(direction, by: EmbroideryAngle(degrees: Double((Int(angle.degrees) % 10))/2.0)))
        }
         */
    }
         
    
    @discardableResult
    public func jump(to point: EmbroideryPoint) -> [RenderingOperation] {
        let oldPosition = currentPosition
        
        let newOps = [
            Operation(type: .jump, at: currentPosition),
            Operation(type: .jump, at: point)
        ]
        
        operations.append(newOps)
        currentPosition = point
        
        return [.jump(oldPosition.toCanvasCoords(), currentPosition.toCanvasCoords())]
    }
    
    @discardableResult
    public func turn(_ turnDirection: EmbroideryAngle.TurnDirection = .clockwise,
                     by angle: EmbroideryAngle) -> [RenderingOperation] {
        let newAngle = turnDirection == .clockwise ? currentAngle + angle : currentAngle - angle
        let oldAngle = currentAngle
        
        currentAngle = newAngle
        
        return [.turn(oldAngle.swiftUIAngle, currentAngle.swiftUIAngle)]
    }
    
    @discardableResult
    public func turn(to angle: EmbroideryAngle) -> [RenderingOperation] {
        let oldAngle = currentAngle
        
        currentAngle = angle
        
        return [.turn(oldAngle.swiftUIAngle, currentAngle.swiftUIAngle)]
    }
    
    @discardableResult
    public func turn(toFace point: EmbroideryPoint) -> [RenderingOperation] {
        let oldAngle = currentAngle
        
        let diff = point - currentPosition
        let newAngle = diff.phase
        currentAngle = newAngle
        
        return [.turn(oldAngle.swiftUIAngle, currentAngle.swiftUIAngle)]

    }
    
    @discardableResult
    public func changeColor(to color: EmbroideryColor) -> [RenderingOperation] {
        let newOps = [
            Operation(type: .colorChange, at: currentPosition, color: color)
        ]
        
        currentColor = color
        
        operations.append(newOps)
        
        return [] // there isn't a rendering op for change color
    }
    
    @discardableResult
    public func changeStitchType(to stitchType: StitchType) -> [RenderingOperation] {
        self.currentStitch = stitchType
        
        return [] // change stitch type doesn't generate any ops, only updates state
    }
    
    // MARK: - CustomPlaygroundDisplayConvertible
    
    public func bezierCurve() -> UIBezierPath {
        let points = operations.flatMap { operations in
            operations.map {
                $0.cgPoint
            }
        }
        
        let path = UIBezierPath()
        
        if let firstPoint = points.first {
            path.move(to: firstPoint)
        }
        
        for point in points {
            path.addLine(to: point)
        }
        
        for point in points.reversed() {
            path.addLine(to: point)
        }
        
        return path
    }
    
    public var playgroundDescription: Any {
        bezierCurve()
    }
}
