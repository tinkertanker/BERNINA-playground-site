//
//  Project.swift
//  BianCore
//
//  Created by Jia Chen Yee on 19/2/23.
//

import Foundation
import UIKit
import SwiftUI

/// Main class responsibile for keeping track of state and generating the list of ``Operation``s and ``RenderingOperation``s.
/// The ``Operation``s will be appended to ``operations`` and kept as state, whereas the ``RenderingOperation``s will be returned as
///
/// > Note: ``Operation``s are for the embroidary machine (to be converted into .exp files), whereas ``RenderingOperation``s are for the live view to animate and draw
public class Project: CustomPlaygroundDisplayConvertible {
    
    // MARK: - Constants (starting state)
    static let startingAngle: EmbroideryAngle = .zero
    static let startingPosition: EmbroideryPoint = .init(x: 50, y: 65)
    static let startingColor: EmbroideryColor = .red
    
    
    // MARK: - State
    
    // Note: this could just be a flattened array of ops [Operation]
    //       but we use another nested array to group one "method"'s operations together.
    // E.g. moveForward() can generate multiple `Operations`s because of the different stich types.
    public var operations: [[Operation]] = [] // public for debugging purposes so i can inspect the operations
    
    // Current State
    var currentStitch: StitchType = DefaultStitch()
    
    var currentAngle = Project.startingAngle
    var currentPosition = Project.startingPosition
    var currentColor = Project.startingColor
    
    public init() {
        changeColor(to: currentColor)
    }
    
    // MARK: - Public API
    
    /// Returns the new operations that this command has generated
    @discardableResult
    public func move(by distance: EmbroideryDistance) -> [RenderingOperation] {
        
        guard !distance.isZero else { return [] }
        
        // generate new ops
        let (newOps, newRenderingOps) = currentStitch.calcOps(withLength: distance, from: currentPosition, facing: currentAngle, color: currentColor)
        
        // update state
        guard let newPos = newOps.last?.embroideryPoint else { return [] }
        currentPosition = newPos
        operations.append(newOps)
        
        return newRenderingOps
    }

    @discardableResult
    public func move(to point: EmbroideryPoint) -> [RenderingOperation] {
        let a = point.x - currentPosition.x
        let b = point.y - currentPosition.y
        let distance = (a*a + b*b).squareRoot()
        
        let turnOps = self.turn(toFace: point)
        let moveOps = self.move(by: distance)
        
        return turnOps + moveOps
    }
    
    @discardableResult
    public func jump(to point: EmbroideryPoint) -> [RenderingOperation] {
        let oldPosition = currentPosition
        
        let newOps = [
            Operation(type: .jump, at: currentPosition),
            Operation(type: .jump, at: point)
        ]
        
        operations.append(newOps)
        currentPosition = point
        
        return [.jump(oldPosition.toCanvasCoords(), currentPosition.toCanvasCoords())]
    }
    
    @discardableResult
    public func turn(_ turnDirection: EmbroideryAngle.TurnDirection = .clockwise,
                     by angle: EmbroideryAngle) -> [RenderingOperation] {
        let normAngle = (currentAngle + angle).remainder(dividingBy: .pi * 2)
        
        let oldAngle = currentAngle
        
        currentAngle = turnDirection == .clockwise ? normAngle : .degrees(360) - normAngle
        
        return [.turn(oldAngle.swiftUIAngle, currentAngle.swiftUIAngle)]
    }
    
    @discardableResult
    public func turn(to angle: EmbroideryAngle) -> [RenderingOperation] {
        let normAngle = angle.remainder(dividingBy: .pi * 2)
        
        let oldAngle = currentAngle
        
        currentAngle = normAngle
        
        return [.turn(oldAngle.swiftUIAngle, currentAngle.swiftUIAngle)]
    }
    
    @discardableResult
    public func turn(toFace point: EmbroideryPoint) -> [RenderingOperation] {
        let oldAngle = currentAngle
        
        let diff = point - currentPosition
        let newAngle = diff.phase
        currentAngle = newAngle
        
        return [.turn(oldAngle.swiftUIAngle, currentAngle.swiftUIAngle)]

    }
    
    @discardableResult
    public func changeColor(to color: EmbroideryColor) -> [RenderingOperation] {
        let newOps = [
            Operation(type: .colorChange, at: currentPosition, color: color)
        ]
        
        currentColor = color
        
        operations.append(newOps)
        
        return [] // there isn't a rendering op for change color
    }
    
    @discardableResult
    public func changeStitchType(to stitchType: StitchType) -> [RenderingOperation] {
        self.currentStitch = stitchType
        
        return [] // change stitc type doesn't generate any ops, only updates state
    }
    
    // MARK: - CustomPlaygroundDisplayConvertible
    
    public func bezierCurve() -> UIBezierPath {
        let points = operations.flatMap { operations in
            operations.map {
                $0.cgPoint
            }
        }
        
        let path = UIBezierPath()
        
        if let firstPoint = points.first {
            path.move(to: firstPoint)
        }
        
        for point in points {
            path.addLine(to: point)
        }
        
        for point in points.reversed() {
            path.addLine(to: point)
        }
        
        return path
    }
    
    public var playgroundDescription: Any {
        bezierCurve()
    }
}
