// swiftlint:disable all
//
//  Guide.swift
//  BERNINA
//
//  Created by Jia Chen Yee on 16/10/22.
//

import Foundation

struct Guide: Identifiable {
    var id: String { name }
    var name: String
    var icon: String
    var description: String
    
    static let guides = [
        Guide(name: "Send to a USB drive", icon: "externaldrive", description: """
If you have an [iPad with a USB-C port](https://support.apple.com/en-us/HT209186), you can use a USB-C and USB-A thumb drive and plug it into your iPad to send the embroidery file over to the BERNINA machine.
"""),
        Guide(name: "Using a Lighting to USB adapter", icon: "cable.connector.horizontal", description: """
If you have an iPad with a Lightning port, consider using a [Lightning to USB 3 Camera Adapter](https://www.apple.com/shop/product/MK0W2AM/A/lightning-to-usb-3-camera-adapter). The adapter will allow you to plug in a thumb drive into your iPad and send the embroidery file from your iPad to the BERNINA machine.
"""),
        Guide(name: "Using a USB-C to USB adapter", icon: "cable.connector.horizontal",
              description: "If you have an iPad with a USB-C port, consider using a [USB-C to USB Adapter](https://www.apple.com/shop/product/MJ1M2AM/A/usb-c-to-usb-adapter). The adapter will allow you to plug in a thumb drive into your iPad and send the embroidery file from your iPad to the BERNINA machine."),
        Guide(name: "Send to another device", icon: "square.and.arrow.up", description: "If you do not have an adapter on hand, you can share the embroidery file to another computer by using the **Send File** button. With this, you can share this file to a Mac using [AirDrop](https://support.apple.com/en-us/HT204144) or share the file using Mail and email it to yourself. From there, you can download the files, plug a thumb drive into your computer, and send the file to your BERNINA machine.")
    ]
}
