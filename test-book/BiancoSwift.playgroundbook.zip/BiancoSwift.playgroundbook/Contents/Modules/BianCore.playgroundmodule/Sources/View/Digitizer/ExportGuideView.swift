//
//  ExportGuideView.swift
//  BERNINA
//
//  Created by Jia Chen Yee on 16/10/22.
//

import SwiftUI

struct ExportGuideView: View {
    var body: some View {
        List {
            ForEach(Guide.guides) { guide in
                NavigationLink {
                    ScrollView {
                        Text((try? AttributedString(markdown: guide.description)) ?? "")
                            .padding(.horizontal)
                    }
                    .navigationTitle(guide.name)
                } label: {
                    Label(guide.name, systemImage: guide.icon)
                }

            }
        }
        .navigationTitle("Sending to BERNINA Machine")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct ExportGuideView_Previews: PreviewProvider {
    static var previews: some View {
        ExportGuideView()
    }
}
