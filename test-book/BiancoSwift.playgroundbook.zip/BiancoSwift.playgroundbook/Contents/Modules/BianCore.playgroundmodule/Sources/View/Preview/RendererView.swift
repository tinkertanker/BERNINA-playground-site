//
//  RendererView.swift
//  BianCore
//
//  Created by Jia Chen Yee on 19/2/23.
//

import SwiftUI

extension CGRect {
    init(center: CGPoint, size: CGSize) {
        self.init(x: center.x - size.width / 2, y: center.y - size.height / 2, width: size.width, height: size.height)
    }
}

extension GraphicsContext {
    func drawLine(from: CGPoint, to: CGPoint, color: Color) {
        let path = Path { $0.move(to: from); $0.addLine(to: to) }
        self.stroke(path, with: .color(color),lineWidth: 5)
    }
}

struct RendererView: View {
    
    @ObservedObject var renderViewModel: RendererViewModel
    
    var body: some View {
        ZStack {
            GridView()
            
            GeometryReader { geometry in
                let width = CGFloat(10) * squareSize
                let height = CGFloat(13) * squareSize
                let startX = (geometry.size.width - width) / 2
                let startY = (geometry.size.height - height) / 2 - squareSize / 2
                
                // Draw the stuff that doesn't need to be animated
                Canvas() { context, size in
                    for renderingOp in renderViewModel.toRenderImmediately {
                        switch renderingOp {
                        case .line(let from, let to, let color):
                            context.drawLine(from: from, to: to, color: color)
                            let circlePath = Circle().path(in: CGRect(center: to, size: CGSize(width: 10, height: 10)))
                            context.fill(circlePath, with: .color(.white))
                        default:
                            continue
                        }
                    }
                }
                .offset(x: startX, y: startY + squareSize / 2)
                
                // Draw the stitch (white) dots on top of all the other lines so they don't get overlapped
                Canvas() { context, size in
                    for renderingOp in renderViewModel.toRenderImmediately {
                        switch renderingOp {
                        case .line(let from, let to, _):
                            let size = 10.0
                            context.fill(Circle().path(in: CGRect(center: from, size: CGSize(width: size, height: size))), with: .color(.white))
                            context.fill(Circle().path(in: CGRect(center: to, size: CGSize(width: size, height: size))), with: .color(.white))
                        default:
                            continue
                        }
                    }
                }
                .offset(x: startX, y: startY + squareSize / 2)
                
                // Animated stuff
                TimelineView(.animation) { timeline in
                    Canvas() { context, size in
                        let now = timeline.date.timeIntervalSinceReferenceDate
                        renderViewModel.update(time: now)
                        
                        // debug text
                        context.draw(context.resolve(Text("\(renderViewModel.debugDescription)")), at: CGPoint(x:0,y:0), anchor: .topLeading)
//                        context.draw(context.resolve(Text(renderViewModel.debugText.joined(separator: "\n"))), at: CGPoint(x:0,y:50), anchor: .topLeading)

                        // draw the partial line
                        if let (from, to, color) = renderViewModel.currentPartialLine {
                            context.drawLine(from: from, to: to, color: color)
                        }

                        // draw the turtle
                        let turtleSymbol = context.resolveSymbol(id: 0)!
                        context.draw(turtleSymbol, at: renderViewModel.currentTurtlePos, anchor: .center)

                    } symbols: {
                        // The turtle symbol, change this to any SwiftUI view you want to represent the turtle
                        Text("🐢")
                            .font(.system(size: 64))
                            .scaleEffect(x: -1)
                            .rotationEffect(renderViewModel.currentTurtleAngle)
                            .tag(0) // this tag(0) is important for referencing inside the graphics context
                    }
                    .offset(x: startX, y: startY + squareSize / 2)
                }

            }
        }
        .frame(width: 1000 * 2, height: 1300 * 2)
        .scaleEffect(x: 0.5, y: 0.5)
    }
}
