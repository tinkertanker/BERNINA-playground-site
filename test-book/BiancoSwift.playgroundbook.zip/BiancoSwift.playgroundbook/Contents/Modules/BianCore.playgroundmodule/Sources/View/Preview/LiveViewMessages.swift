//
//  LiveViewMessages.swift
//  BianCore
//
//  Created by T Krobot on 19/9/23.
//

import Foundation
import PlaygroundSupport

/// Messages for communicating events between the live view and the playground page
public enum LiveViewMessages {
    /// The playground page should send this after all the drawing code has finished executing,
    /// so the live view will know to send `stopExecution` after the animations have finished.
    public static let finished = "finished"
    
    /// The live view will send this to the playground page after the animation has finished AND after it has received the `finished` event.
    /// The playground page should call `finishExecution()` after receiving this event
    public static let stopExecution = "stop execution"
    
    /// The playgruond page should send this at the start of execution.
    /// The live veiw should reset to it's original state after receiving this event.
    /// This is so when you run the playground again the preview still works as expected
    public static let reset = "reset"
    
    /// The playground page sends thsi error when there was a problem encoding the data to send over to the live view.
    /// Should indicate a bug in the code if it shows up. It shouldn't be part of normal execution
    public static let encodingError = "encoding error"
}

public struct LiveViewMessageData: Codable {
    var operations: [[Operation]]
    var newRenderingOps: [RenderingOperation]
    
    public init(operations: [[Operation]], newRenderingOps: [RenderingOperation]) {
        self.operations = operations
        self.newRenderingOps = newRenderingOps
    }
}
