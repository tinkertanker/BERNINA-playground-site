//
//  GridView.swift
//  BianCore
//
//  Created by Jia Chen Yee on 19/2/23.
//

import SwiftUI

let squareSize: CGFloat = 100

struct GridView: View {
    var body: some View {
        GeometryReader { geometry in
            let width = CGFloat(10) * squareSize
            let height = CGFloat(13) * squareSize
            let startX = (geometry.size.width - width) / 2
            let startY = (geometry.size.height - height) / 2 - squareSize / 2
            
            Path { path in
                for row in 0..<14 {
                    for col in 0..<10 {
                        let x = startX + CGFloat(col) * squareSize
                        var y = startY + CGFloat(row) * squareSize
                        
                        // Calculate the height of the square
                        var squareHeight = squareSize
                        if row == 0 || row == 13 {
                            squareHeight /= 2
                        }
                        
                        if row == 0 {
                            y += squareHeight
                        }
                        
                        // Add the square to the path
                        path.addRect(CGRect(x: x, y: y, width: squareSize, height: squareHeight))
                    }
                }
            }
            .stroke(Color("AccentColor").opacity(0.5), lineWidth: 0.5)
            
            Rectangle()
                .stroke(Color("AccentColor"), lineWidth: 5)
                .frame(width: width, height: height)
                .offset(x: startX, y: startY + squareSize / 2)
        }
    }
}
