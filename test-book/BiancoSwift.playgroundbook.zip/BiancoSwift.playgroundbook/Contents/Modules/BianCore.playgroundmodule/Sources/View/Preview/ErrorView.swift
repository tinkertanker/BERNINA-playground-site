//
//  ErrorView.swift
//  BianCore
//
//  Created by Jia Chen Yee on 19/2/23.
//

import Foundation
import SwiftUI

struct ErrorView: View {
    var body: some View {
        VStack {
            Image(systemName: "exclamationmark.triangle.fill")
                .symbolRenderingMode(.multicolor)
            Text("Something went wrong.")
                .font(.headline)
                .multilineTextAlignment(.center)
            Text("Check through your code and try again!")
                .font(.subheadline)
                .multilineTextAlignment(.center)
        }
    }
}
