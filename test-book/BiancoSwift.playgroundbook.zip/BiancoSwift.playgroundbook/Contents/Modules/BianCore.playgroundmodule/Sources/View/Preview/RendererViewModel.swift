//
//  RendererViewModel.swift
//  BianCore
//
//  Created by T Krobot on 15/9/23.
//

import Foundation
import SwiftUI

// Animation functions (https://rtorres.me/blog/lerp-swift/)
@inline(__always)
func lerp<V: BinaryFloatingPoint, T: BinaryFloatingPoint>(_ v0: V, _ v1: V, _ t: T) -> V {
    return v0 + V(t) * (v1 - v0)
}

@inline(__always)
func lerp<T: BinaryFloatingPoint>(_ p0: CGPoint, _ p1: CGPoint, _ t: T) -> CGPoint {
    return CGPoint(
        x: lerp(p0.x, p1.x, t),
        y: lerp(p0.y, p1.y, t)
    )
}

@inline(__always)
func lerp<T: BinaryFloatingPoint>(_ v0: Angle, _ v1: Angle, _ t: T) -> Angle {
    return Angle(radians: lerp(v0.radians, v1.radians, t))
}

public class RendererViewModel: ObservableObject {
    @Published private(set) var renderingOps: [RenderingOperation]
    
    // TODO: change this to just use animationIndex and everything < animationIndex will not be animated
    @Published private(set) var toRenderImmediately = [RenderingOperation]()
    
    @Published private(set) var currentTurtlePos: CGPoint
    @Published private(set) var currentTurtleAngle: Angle
    
    @Published private(set) var finished = false
    
    @Published public var debugText = [String]()
    
    @Published public var stopAnimation = false
    
    /// The core counter driving the animations.
    ///
    /// > Note: This number should only ever go up
    private var animationIndex: Int = -1 {
        didSet {
            if currentRenderingOp == nil {
                finished = true
            }
        }
    }
    
    private var animationPercent: Double = 0
    
    /// Gets the current `RenderingOperation` being animated based on the `animationIndex`.
    /// Is `nil` if all the rendering operations have finished running / there are no renderingOps.
    /// Could also indicate a bug in controlling the `animationIndex` and `renderingOps`
    private var currentRenderingOp: RenderingOperation? {
        // check that animationIndex is within range
        guard animationIndex < renderingOps.count else { return nil }
        guard animationIndex >= 0 else { return nil }
        
        return renderingOps[animationIndex]
    }
    
    private var targetTurtlePos: CGPoint? {
        currentRenderingOp?.getTarget()
    }
    
    private var targetTurtleAngle: Angle? {
        currentRenderingOp?.getTargetAngle()
    }
    
    public var currentPartialLine: (from: CGPoint, to: CGPoint, color: Color)? {
        guard let currentRenderingOp else { return nil }
        switch currentRenderingOp {
        case .line(let from, _, let color):
            return (from: from, to: currentTurtlePos, color: color)
        default:
            return nil
        }
    }
    
    private var originalTurtlePos: CGPoint
    private var originalTurtleAngle: Angle
    
    public var animationSpeedMultiplier = 1.0
    
    private var animationSpeed: Double {
        guard let currentRenderingOp else { return 0 }
        switch currentRenderingOp {
        case .line(let from, let to, _):
            // draw the line at a constant speed
            // so a longer line should have a slower animation speed
            let distance = to.distance(from: from)
            let lineDrawingSpeed = 2.0
            return animationSpeedMultiplier * lineDrawingSpeed / distance
        default:
            return animationSpeedMultiplier * 0.1
        }
    }
    
    private var lastTime = 0.0
    
    init() {
        self.renderingOps = []
        
        let pos = Project.startingPosition.toCanvasCoords()
        let angle = Project.startingAngle.swiftUIAngle
        
        currentTurtlePos = pos
        currentTurtleAngle = angle
        
        originalTurtlePos = pos
        originalTurtleAngle = angle
    }
    
    public func update(time: TimeInterval) {
        let deltaTime = min(time - lastTime, 1.0/30.0)
        lastTime = time
        
        guard deltaTime > 0 else { return }
        
        if stopAnimation { return }
        
        guard currentRenderingOp != nil else { return }
        
        // move the current pos and angle towards the current pos and angle
        animationPercent += animationSpeed;
        
        if animationPercent >= 1 {
            completedRenderingOp()
        } else {
            if let targetTurtlePos {
                currentTurtlePos = lerp(originalTurtlePos, targetTurtlePos, animationPercent)
            }
            if let targetTurtleAngle {
                currentTurtleAngle = lerp(originalTurtleAngle, targetTurtleAngle, animationPercent)
            }
        }
    }
    
    public func reset() {
        renderingOps = []
        toRenderImmediately = []
        animationIndex = 0
        animationPercent = 0
        
        stopAnimation = false
        finished = false
        
        let pos = CGPoint(x: 500, y: 650)
        let angle = Angle.zero
        
        currentTurtlePos = pos
        currentTurtleAngle = angle
        
        originalTurtlePos = pos
        originalTurtleAngle = angle
        
//        targetTurtlePos = pos
//        targetTurtleAngle = angle
    }
    
    public func append(newRenderingOps: [RenderingOperation]) {
        newRenderingOps.forEach { debugText.append("\($0)") }
        
        renderingOps.append(contentsOf: newRenderingOps)
        
        if !renderingOps.isEmpty && animationIndex == -1 {
            animationIndex = 0
        }
    }
    
    /// This should be called when the current rendring op has finished animating.
    private func completedRenderingOp() {
        // TODO: extract this into the willSet for animationIndex?
        originalTurtlePos = currentTurtlePos
        originalTurtleAngle = currentTurtleAngle
        animationPercent = 0
        
        toRenderImmediately.append(currentRenderingOp!)
        animationIndex += 1
    }
    
//    private func updateTarget(renderingOp: RenderingOperation) {
//        switch renderingOp {
//        case .line(_, let to, _): targetTurtlePos = to
//        case .jump(_, let to): targetTurtlePos = to
//        case .turn(_, let to): targetTurtleAngle = to
//        }
//    }
}

extension RendererViewModel: CustomDebugStringConvertible {
    public var debugDescription: String {
        "target pos: \(String(describing: targetTurtlePos)), target angle: \(String(describing: targetTurtleAngle)), animationPercent: \(animationPercent)"
//        "animationIndex: \(animationIndex), currentRenderingOp: \(String(describing: currentRenderingOp)), animationPercent: \(animationPercent)"
    }
}

extension EmbroideryAngle {
    public var swiftUIAngle: Angle {
        Angle(radians: radians)
    }
}
