//
//  DigitizedDesignPreviewView.swift
//  BERNINA
//
//  Created by Jia Chen Yee on 6/3/22.
//

import SwiftUI
import PlaygroundSupport

struct ExportToMachineView: View {
    
    @State var presentDocumentPicker = false
    
    @State var saveLocation: URL?
    
    @State var fileName = ""
    
    @State var isAlertPresented = false
    
    @State var finalFileName = ""
    
    var output: DigitizerOutput
    
    @State var savedFileName: String?
    
    var body: some View {
        NavigationStack {
            Form {
                Section("File name") {
                    TextField("Playground" + ".exp", text: $fileName)
                }
                
                Section("Saving Embroidery File") {
                    Button {
                        presentDocumentPicker = true
                    } label: {
                        HStack {
                            Text("Save to…")
                                .foregroundColor(.primary)
                            
                            Spacer()
                            
                            ProgressView()
                                .hidden().frame(width: 0, height: 0)
                            
                            Text(saveLocation?.directoryName ?? "Select Location")
                        }
                    }
                    
                    HStack {
                        Text("Embroidery File Generated")
                        
                        Spacer()
                        
                        Text(ByteCountFormatter().string(fromByteCount: Int64(output.totalData.count)))
                            .foregroundStyle(.secondary)
                    }
                }
                Section {
                    NavigationLink {
                        ExportGuideView()
                    } label: {
                        Label("Sending to BERNINA Machine", systemImage: "book.closed")
                    }
                    
                    Button {
                        saveEXP()
                    } label: {
                        Text("Save")
                    }
                    .disabled(saveLocation == nil)
                }
            }
            .navigationTitle("Export to Machine")
        }
        .sheet(isPresented: $presentDocumentPicker) {
            DocumentPickerView(url: $saveLocation)
        }
        .alert("Saved \"\(finalFileName)\" Successfully", isPresented: $isAlertPresented) {
            Button("OK") {}
        } message: {
            Text("You can unplug your USB drive and plug it into your BERNINA machine")
        }

    }
    
    func saveEXP() {
        
        guard let saveLocation = saveLocation else { return }
        
        let fileNameArray = Array(fileName)
        
        let modifiedFileName = fileName.hasSuffix(".exp") ? String(fileNameArray[0..<fileName.count - 4]) : fileName
        
        let documentName = fileName.isEmpty ? "Playground" : modifiedFileName

        let expName = documentName + ".exp"
        let infName = documentName + ".inf"
        
        if saveLocation.startAccessingSecurityScopedResource() {
            defer {
                saveLocation.stopAccessingSecurityScopedResource()
            }

            do {
                let contents = try FileManager.default.contentsOfDirectory(at: saveLocation,
                                                                           includingPropertiesForKeys: nil)

                let savedEXPFileName = getFileName(withOriginal: expName, fileExtension: "exp",
                                                   contentsOfDirectory: contents)
                let savedINFFileName = getFileName(withOriginal: infName, fileExtension: "inf",
                                                   contentsOfDirectory: contents)

                try output.exp.write(to: saveLocation.appendingPathComponent(savedEXPFileName))
                try output.inf.write(to: saveLocation.appendingPathComponent(savedINFFileName))

                finalFileName = savedEXPFileName
                
                isAlertPresented = true

                self.savedFileName = savedFileName
            } catch {
                print(error.localizedDescription)
            }
        }
    }
    
    func getFileName(withOriginal originalFileName: String, fileExtension: String,
                     contentsOfDirectory: [URL]) -> String {
        var suffix = 0
        
        var documentName = originalFileName
        
        // Use a for-loop to prevent a case of an accidental infinite loop
        for _ in 0..<contentsOfDirectory.count {
            if !contentsOfDirectory.contains(where: { $0.lastPathComponent == documentName }) {
                return documentName
            }
            
            suffix += 1
            
            var mutableFileName = originalFileName
            
            // Remove file extension
            mutableFileName.removeLast(4)
            
            // Add "copy"
            mutableFileName += " copy"
            
            // Add number suffix
            if suffix > 1 {
                mutableFileName += " \(suffix)"
            }
            
            // Add file extension back
            mutableFileName += ".\(fileExtension)"
            
            documentName = mutableFileName
        }
        
        var mutableFileName = originalFileName
        
        // If all else fails, just use a randomly generated string at the end of it.
        mutableFileName.removeLast(4)
        mutableFileName += UUID().uuidString.split(separator: "-").last!
        mutableFileName += ".exp"
        
        documentName = mutableFileName
        
        return documentName
    }
}

extension URL {
    var directoryName: String {
        if pathComponents.count == 9 && lastPathComponent == "File Provider Storage" {
            
            let deviceName = { () -> String in
                switch UIDevice.current.userInterfaceIdiom {
                case .carPlay: return "Car"
                case .mac: return "Mac"
                case .pad: return "iPad"
                case .phone: return "iPhone"
                case .tv: return "Apple TV"
                default: return "Device"
                }
            }()
            
            return "On my \(deviceName)"
        } else {
            return lastPathComponent
        }
    }
}
