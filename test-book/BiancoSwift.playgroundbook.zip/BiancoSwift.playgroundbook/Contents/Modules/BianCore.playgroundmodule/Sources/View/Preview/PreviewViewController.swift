//
//  PreviewViewController.swift
//  BianCore
//
//  Created by Jia Chen Yee on 19/2/23.
//

import UIKit
import PlaygroundSupport
import Combine
import SwiftUI

public func instantiateLiveView() -> PlaygroundLiveViewable {
    let liveViewController = PreviewViewController()
    
    return liveViewController
}

public class PreviewViewController: UIViewController, PlaygroundLiveViewMessageHandler, PlaygroundLiveViewSafeAreaContainer, UIScrollViewDelegate {
    
    private var hostedSwiftUIView: UIView?
    
    var errorView: UIView!
    var operations: [[Operation]] = [] {
        didSet {
            exportButton.isEnabled = !operations.isEmpty
        }
    }
    let scrollView = UIScrollView()
    
    var exportButton: UIButton!
    
    var rendererViewModel = RendererViewModel()
    
    private var finishedSubscriber: AnyCancellable?
    
    public override func loadView() {
        super.loadView()
    }
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        setupError()
        setUpScrollView()
        setUpExportButton()
        
        // setup the renderer thing
        oldScale = scrollView.zoomScale
        oldContentOffset = scrollView.contentOffset
        
        let hostingView = UIHostingController(rootView: RendererView(
            renderViewModel: rendererViewModel)).view!
        
        display(hostedSwiftUIView: hostingView)
        
        recenterContent()
        
        scrollView.zoomScale = oldScale
        scrollView.setContentOffset(oldContentOffset, animated: false)
        
        
        errorView.isHidden = true
    }
    
    func setUpExportButton() {
        let button = UIButton()
        button.setImage(UIImage(systemName: "paperplane"), for: .normal)
        button.setTitle("Export to Machine", for: .normal)
        button.configuration = .borderedProminent()
        button.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(button)
        
        view.addConstraints([
            NSLayoutConstraint(item: button, attribute: .bottom, relatedBy: .equal, toItem: view, attribute: .bottomMargin, multiplier: 1, constant: 0),
            NSLayoutConstraint(item: button, attribute: .leading, relatedBy: .equal, toItem: view, attribute: .leadingMargin, multiplier: 1, constant: 0)
        ])
        
        // Activate the constraints
        button.layer.zPosition = 5
        button.addAction(UIAction(handler: { [self] _ in
            let hostingView = UIHostingController(rootView: ExportToMachineView(output: operations.getDigitizerOutput()))
            
            self.present(hostingView, animated: true)
        }), for: .touchUpInside)
        
        self.exportButton = button
    }
    
    func setUpScrollView() {
        scrollView.delegate = self
        scrollView.minimumZoomScale = 0.05
        scrollView.maximumZoomScale = 10.0
        
        scrollView.showsVerticalScrollIndicator = true
        scrollView.showsHorizontalScrollIndicator = true
        
        scrollView.backgroundColor = .clear
        
        scrollView.isUserInteractionEnabled = true
        
        view.addSubview(scrollView)
        
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            scrollView.topAnchor.constraint(equalTo: view.topAnchor),
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            scrollView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
        ])
        
    }
    
    var oldContentOffset = CGPoint.zero
    
    public func receive(_ message: PlaygroundValue) {
        switch message {
        case .data(let data):
            guard let liveViewMessageData = try? JSONDecoder().decode(LiveViewMessageData.self, from: data) else {
                errorView.isHidden = false
                return
            }
            
            errorView.isHidden = true
            
            let ops = liveViewMessageData.operations
            let newRendringOps = liveViewMessageData.newRenderingOps
            
            // add operations to own state so the Export button can do it's work
            self.operations = ops
            
            // send the new rendering ops to the SwiftUI view through ObservableObject
            rendererViewModel.append(newRenderingOps: newRendringOps)
        
        case .string(LiveViewMessages.finished):
            finishedSubscriber = rendererViewModel.$finished.sink { newValue in
                if newValue {
                    self.rendererViewModel.debugText.append("stop execution")
                    self.send(.string(LiveViewMessages.stopExecution))
                    self.finishedSubscriber?.cancel()
                    self.finishedSubscriber = nil
                }
            }
        
        case .string(LiveViewMessages.reset):
            finishedSubscriber?.cancel()
            finishedSubscriber = nil
            rendererViewModel.reset()
            
        case .floatingPoint(let animationSpeedMultiplier):
            rendererViewModel.animationSpeedMultiplier = animationSpeedMultiplier
            
        default:
            errorView.isHidden = false
        }
    }
    
    public func liveViewMessageConnectionClosed() {
        rendererViewModel.stopAnimation = true
    }
    
    func setupError() {
        // Wrap the SwiftUI view in a UIHostingController
        let errorView = UIHostingController(rootView: ErrorView()).view!
        
        // Add the hosting controller to the view hierarchy
        view.addSubview(errorView)
        
        errorView.translatesAutoresizingMaskIntoConstraints = false
        errorView.leadingAnchor.constraint(equalTo: view.leadingAnchor).isActive = true
        errorView.trailingAnchor.constraint(equalTo: view.trailingAnchor).isActive = true
        errorView.topAnchor.constraint(equalTo: view.topAnchor).isActive = true
        errorView.bottomAnchor.constraint(equalTo: view.bottomAnchor).isActive = true
        
        self.errorView = errorView
    }
    
    var oldScale = 1.0
    
    func display(hostedSwiftUIView: UIView) {
        
        self.hostedSwiftUIView = hostedSwiftUIView
        
        for subview in scrollView.subviews {
            subview.removeFromSuperview()
        }
        
        hostedSwiftUIView.backgroundColor = .clear
        hostedSwiftUIView.isUserInteractionEnabled = false
        
        scrollView.addSubview(hostedSwiftUIView)
        
        
        hostedSwiftUIView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            hostedSwiftUIView.topAnchor.constraint(equalTo: scrollView.topAnchor),
            hostedSwiftUIView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor),
            hostedSwiftUIView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor),
            hostedSwiftUIView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor),
            hostedSwiftUIView.widthAnchor.constraint(equalTo: scrollView.widthAnchor),
            hostedSwiftUIView.heightAnchor.constraint(equalTo: scrollView.heightAnchor),
        ])
    }
    
    public override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        
        coordinator.animate { [self] _ in
            recenterContent()
        }
    }
    
    public func viewForZooming(in scrollView: UIScrollView) -> UIView? {
        if let hostedSwiftUIView {
            return hostedSwiftUIView
        } else {
            scrollView.backgroundColor = .systemBackground
            return nil
        }
    }
    
    @discardableResult
    func recenterContent() -> CGPoint {
        let offsetX = max((scrollView.bounds.width - scrollView.contentSize.width) * 0.5, 0)
        let offsetY = max((scrollView.bounds.height - scrollView.contentSize.height) * 0.5, 0)
        scrollView.contentInset = UIEdgeInsets(top: offsetY, left: offsetX, bottom: 0, right: 0)
        
        return .init(x: offsetX, y: offsetY)
    }
    
    public func scrollViewDidZoom(_ scrollView: UIScrollView) {
        recenterContent()
    }
    
    public override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        recenterContent()
    }
}
