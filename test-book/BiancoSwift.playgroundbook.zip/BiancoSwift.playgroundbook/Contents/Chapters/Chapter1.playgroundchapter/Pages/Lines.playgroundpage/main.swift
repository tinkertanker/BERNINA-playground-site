//#-hidden-code
import Foundation
import BianCore
import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true

guard let remoteView = PlaygroundPage.current.liveView as? PlaygroundRemoteLiveViewProxy else {
    fatalError("Always-on live view not configured in this page's LiveView.swift.")
}

class MessageHandler: PlaygroundRemoteLiveViewProxyDelegate {
    func remoteLiveViewProxy(
        _ remoteLiveViewProxy: PlaygroundRemoteLiveViewProxy,
        received message: PlaygroundValue
    ) {
//        print("Received a message from the always-on live view: \(message)")
        
        switch message {
        case .string(LiveViewMessages.stopExecution):
            PlaygroundPage.current.finishExecution()
        default:
            break
        }
    }

    func remoteLiveViewProxyConnectionClosed(_ remoteLiveViewProxy: PlaygroundRemoteLiveViewProxy) {
        PlaygroundPage.current.finishExecution()
    }
}

// NOTE for future ppl reading: idk why but if you do remoteView.delegate = MessageHandler() it doesn't work
let handler = MessageHandler()
remoteView.delegate = handler

let project = Project()

let animationSpeedMultiplier = { switch PlaygroundPage.current.executionMode {
case .stepSlowly: return 0.8
case .step: return 1.0
case .run: return 5.0
case .runFaster: return 10.0
case .runFastest: return 20.0
default: return 5.0
}}() // SMH switch expressions (SE-0380) not available yet so we have to do this
    
    
remoteView.send(.floatingPoint(animationSpeedMultiplier))

func send(newRenderingOps: [RenderingOperation]) {
    let messageData = LiveViewMessageData(operations: project.operations, newRenderingOps: newRenderingOps)
    
    let jsonEncoder = JSONEncoder()
    guard let encoded = try? jsonEncoder.encode(messageData) else {
        remoteView.send(.string(LiveViewMessages.encodingError))
        return
    }
    
    remoteView.send(.data(encoded))
}

// MARK: - move

/// Move forward by a given distance.
///
/// ```swift
/// move(.mm(10)) // moves by 10mm
/// move(.cm(1))  // moves by 1cm (or 10mm)
/// ```
@discardableResult func move(_ distance: EmbroideryDistance) -> Project {
    send(newRenderingOps: project.move(by: distance))
    
    return project
}

/// Move forward by a given distance given as a `Double`.
/// The units are assumed to be in mm.
///
/// ```swift
/// move(15.5)
/// ```
@discardableResult func move(_ distance: Double) -> Project {
    return move(.mm(distance))
}

/// Move forward by a given distance given as an `Int`.
/// The units are assumed to be in mm.
///
/// ```swift
/// move(15)
/// ```
@discardableResult func move(_ distance: Int) -> Project {
    return move(.mm(distance))
}


// MARK: - moveTo

/// Move to a certain point
///
/// ```swift
/// move(to: EmbroideryPoint(x: .mm(10), y: .mm(10)))
/// ```
@discardableResult func move(to point: EmbroideryPoint) -> Project {
    send(newRenderingOps: project.move(to: point))
    
    return project
}

/// Move to a certain point (``x``, ``y``) given as `Double`s.
/// The nuits are assumed to be in mm.
@discardableResult func moveTo(x: Double, y: Double) -> Project {
    return move(to: .init(x: x, y: y))
}

/// Move to a certain point (``x``, ``y``) given as `Int`s.
/// The nuits are assumed to be in mm.
@discardableResult func moveTo(x: Int, y: Int) -> Project {
    return move(to: .init(x: x, y: y))
}

// MARK: - jump

/// Jump to a given point without drawing a line.
///
/// ```swift
/// jump(to: EmbroideryPoint(x: .mm(10), y: .mm(10)))
/// ```
@discardableResult func jump(to point: EmbroideryPoint) -> Project {
    send(newRenderingOps: project.jump(to: point))
    
    return project
}

/// Jump to a given point (``x``, ``y``).
///
/// ```swift
/// jumpTo(x: .mm(10), y: .mm(10))
/// ```
@discardableResult func jumpTo(x: EmbroideryDistance, y: EmbroideryDistance) -> Project {
    return jump(to: .init(x: x, y: y))
}

/// Jump to a given point (``x``, ``y``) given as `Double`s.
///
/// ```swift
/// jumpTo(x: 10.5, y: 10.5)
/// ```
@discardableResult func jumpTo(x: Double, y: Double) -> Project {
    return jump(to: .init(x: x, y: y))
}

/// Jump to a given point (``x``, ``y``) given as `Int`s.
///
/// ```swift
/// jumpTo(x: 10, y: 10)
/// ```
@discardableResult func jumpTo(x: Int, y: Int) -> Project {
    return jump(to: .init(x: x, y: y))
}

// MARK: - turn

/// Turn the turtle in a given direction by a given angle.
///
/// - Parameters:
///   - turnDirection: Whether the turning should be clockwise or counter-clockwise
///   - angle: The angle to turn by.
@discardableResult public func turn(_ turnDirection: EmbroideryAngle.TurnDirection,
                                    by angle: EmbroideryAngle) -> Project {
    send(newRenderingOps: project.turn(turnDirection, by: angle))
    
    return project
}
/// Turn the turtle in a given direction by a given angle given as a `Double`.
/// The angle is assumed to be in degrees.
///
/// - Parameters:
///   - turnDirection: Whether the turning should be clockwise or counter-clockwise
///   - angle: The angle to turn by, in degrees.
@discardableResult public func turn(_ turnDirection: EmbroideryAngle.TurnDirection,
                                    by angle: Double) -> Project {
    return turn(turnDirection, by: .degrees(angle))
}
/// Turn the turtle in a given direction by a given angle given as a `Int`.
/// The angle is assumed to be in degrees.
///
/// - Parameters:
///   - turnDirection: Whether the turning should be clockwise or counter-clockwise
///   - angle: The angle to turn by, in degrees.
@discardableResult public func turn(_ turnDirection: EmbroideryAngle.TurnDirection,
                                    by angle: Int) -> Project {
    return turn(turnDirection, by: .degrees(angle))
}

/// Turn the turtle **clockwise** by the given angle.
/// If you need to turn anti-clockwise, see ``turn(_:by:)``, or use a negative angle.
@discardableResult public func turn(_ angle: EmbroideryAngle) -> Project {
    return turn(.clockwise, by: angle)
}
/// Turn the turtle **clockwise** by the given angle given as a `Dobule`.
/// If you need to turn anti-clockwise, see ``turn(_:by:)``, or use a negative angle.
/// The angle is assumed to be in degrees.
@discardableResult public func turn(_ angle: Double) -> Project {
    return turn(.clockwise, by: .degrees(angle))
}
/// Turn the turtle **clockwise** by the given angle given as a `Int`.
/// If you need to turn anti-clockwise, see ``turn(_:by:)``, or use a negative angle.
/// The angle is assumed to be in degrees.
@discardableResult public func turn(_ angle: Int) -> Project {
    return turn(.clockwise, by: .degrees(angle))
}

/// Turn to point in a specific angle.
@discardableResult public func turn(to angle: EmbroideryAngle) -> Project {
    send(newRenderingOps: project.turn(to: angle))
    
    return project
}
/// Turn to point in a specific angle given by a `Double`.
/// The angle is assumed to be in degrees.
@discardableResult public func turn(to angle: Double) -> Project {
    return turn(to: .degrees(angle))
}
/// Turn to point in a specific angle given by an `Int`.
/// The angle is assumed to be in degrees.
@discardableResult public func turn(to angle: Int) -> Project {
    return turn(to: .degrees(angle))
}

/// Turn to face (i.e. point towards) a specific point
@discardableResult public func turn(toFace point: EmbroideryPoint) -> Project {
    send(newRenderingOps: project.turn(toFace: point))
    
    return project
}
/// Turn to face (i.e. point towards) a specific point given by (x, y)
@discardableResult public func turnToFace(x: EmbroideryDistance, y: EmbroideryDistance) -> Project {
    return turn(toFace: .init(x: x, y: y))
}
/// Turn to face (i.e. point towards) a specific point given by (x, y) given as `Double`s
/// The units are assumed to be mm.
@discardableResult public func turnToFace(x: Double, y: Double) -> Project {
    return turn(toFace: .init(x: x, y: y))
}
/// Turn to face (i.e. point towards) a specific point given by (x, y) given as `Int`s
/// The units are assumed to be mm.
@discardableResult public func turnToFace(x: Int, y: Int) -> Project {
    return turn(toFace: .init(x: x, y: y))
}

// MARK: - arc

/// Draws an arc.
///
/// - Parameter direction: The direction to turn to draw the arc
/// - Parameter radius: The radius of the arc
/// - Parameter angle: The angle subtended by the arc. (e.g. `.degrees(180)` will give a semicircle)
/// - Parameter stepSize: Since the arc is being approximated by straight lines, this controls how long each small line is. The shorter the step size, the closer the arc is to a perfect circle. If you make this too big, it will look like a regular polygon.
@discardableResult public func arc(_ direction: EmbroideryAngle.TurnDirection, radius: EmbroideryDistance, angle: EmbroideryAngle, stepSize: EmbroideryDistance = .mm(2)) -> Project {
    send(newRenderingOps: project.arc(direction, radius: radius, angle: angle, stepSize: stepSize))
    
    return project
}

// MARK: - other functions
@discardableResult public func changeColor(to color: EmbroideryColor) -> Project {
    send(newRenderingOps: project.changeColor(to: color))
    
    return project
}

@discardableResult func changeStitchType(to stitchType: StitchType) -> Project {
    send(newRenderingOps: project.changeStitchType(to: stitchType))
    
    return project
}

remoteView.send(.string(LiveViewMessages.reset))

//#-end-hidden-code

/*:
 
 Nice! Now you've learned how to get the turtle to move around and change it's colours! However, just making the turtle move forward would be terrible boring. In this page, we're gonna teach our turtle how to turn!
 
# Teaching the turtle how to turn
 In Bianco, 0° corresponds to north. The full list of degrees is below:
![Compass](Compass.png)
 
 There are 2 ways you can make your turtle turn:
 * Point in direction of Coordinate
 ```swift
 turn(toFace: EmbroideryPoint(x: 100, y: 0))
 ```
 
 * Turn 15 degrees (clockwise or anti-clockwise)
 ```swift
 turn(15)
 ```
 Wanna turn anticlockwise? Add a negative sign before the angle (e.g., turn(-15)).
 ```swift
 turn(-15)
 ```
 
 You can try both types of turning in the code below!
 
 Now, try and draw a square using the turn and move command.
 */

//#-editable-code
turn(15)
turn(toFace: EmbroideryPoint(x: 100, y: 0))
//#-end-editable-code


//#-hidden-code
remoteView.send(.string(LiveViewMessages.finished))
//#-end-hidden-code
