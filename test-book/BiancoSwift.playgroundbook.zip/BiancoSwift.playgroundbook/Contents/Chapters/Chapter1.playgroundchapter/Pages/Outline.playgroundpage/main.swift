//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code

/*:
 # Welcome to the Bianco Playground! Here's a outline of what we're covering today
 * [Introduction to Bianco](Introduction)
 * [Basic Bianco Syntax](Syntax)
 * [Drawing lines and squares](@Lines)
 * [Types of Stitches](Stitches)
 * [Loops](Loops)
 * [Drawing Curves](Curves)
 * [Coordinates](Coordinates)
 * [Further Exploration](Exploration)
*/
