//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code
//#-code-completion(identifier, hide, project, remoteView, MessageHandler, instantiateLiveView(), EmbroideryAngle, EmbroideryColor, EmbroideryDistance, EmbroideryPoint, PreviewViewController, Project)
/*:
# Sewing sounds tough...
* Don’t know how to get started
* Threading the needle; pricking of fingers
* Making too many mistakes; having a messy end product
# Bianco helps with this!
* It's beginner-friendly!
* The machine does all the sewing work - you just design!
* With a good design, you will be guaranteed with a beautiful end product!

Here are some possible images that you can create!
 
![Demo Image 1](Demo_1.png)
![Demo Image 2](Demo_2.png)
![Demo Image 3](Demo_3.png)
![Demo Image 4](Demo_4.png)
 
 # What you'll make
 * You’ll be making a design for a coaster
 * Coaster dimension is approximately 10 cm x 10 cm
 * Do not make your design larger than this
 
 ![Coaster Image](Coaster.jpg)
 */
